import { Router } from "express";
import Groq from "groq-sdk";
import { z } from "zod";

const router = Router();

const Body = z.object({
  audio: z.string().min(1),
  mimeType: z.string().default("audio/webm"),
});

router.post("/", async (req, res) => {
  if (!process.env.GROQ_API_KEY) {
    res.status(503).json({ error: "AI service not configured." });
    return;
  }

  const parsed = Body.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Expected { audio: base64, mimeType: string }" });
    return;
  }

  const { audio, mimeType } = parsed.data;

  try {
    const buffer = Buffer.from(audio, "base64");
    const ext = mimeType.includes("mp4") ? "mp4"
               : mimeType.includes("ogg") ? "ogg"
               : mimeType.includes("wav") ? "wav"
               : "webm";

    const file = new File([buffer], `audio.${ext}`, { type: mimeType });

    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const transcription = await groq.audio.transcriptions.create({
      file,
      model: "whisper-large-v3-turbo",
      response_format: "json",
    });

    res.json({ text: transcription.text ?? "" });
  } catch (err) {
    req.log?.error({ err }, "Transcription failed");
    res.status(500).json({ error: "Transcription failed. Please try again." });
  }
});

export default router;
