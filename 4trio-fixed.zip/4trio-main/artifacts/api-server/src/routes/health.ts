import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { getProviderStatus, isProviderAvailable } from "../lib/providers.js";
import { getHealthReport } from "../lib/model-health.js";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

router.get("/status", (_req, res) => {
  const providers = getProviderStatus();
  const online = Object.values(providers).some((p) => p.configured);
  res.json({ online, providers, modelHealth: getHealthReport() });
});

router.get("/health", (_req, res) => {
  res.json({
    ok: true,
    environment: process.env.NODE_ENV ?? "development",
    providersConfigured: {
      groq:       isProviderAvailable("groq"),
      gemini:     isProviderAvailable("gemini"),
      cerebras:   isProviderAvailable("cerebras"),
      openrouter: isProviderAvailable("openrouter"),
      uncensored: isProviderAvailable("uncensored"),
    },
    providers: getProviderStatus(),
    modelHealth: getHealthReport(),
  });
});

export default router;
