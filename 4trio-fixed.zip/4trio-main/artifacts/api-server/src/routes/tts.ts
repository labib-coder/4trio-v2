import { Router } from "express";
import Groq from "groq-sdk";
import { z } from "zod";

const router = Router();

const Body = z.object({
  text: z.string().min(1).max(4000),
  voice: z.string().optional(),
});

// ─── Split text into ≤190-char chunks at sentence boundaries ──────────────
function splitChunks(text: string, maxLen = 190): string[] {
  const chunks: string[] = [];
  // Split on sentence boundaries
  const sentences = text.match(/[^.!?…]+[.!?…]*/g) ?? [text];
  let current = "";

  for (const raw of sentences) {
    const s = raw.trim();
    if (!s) continue;

    if ((current ? current + " " + s : s).length <= maxLen) {
      current = current ? current + " " + s : s;
    } else {
      if (current) chunks.push(current);
      if (s.length > maxLen) {
        // Break at word boundary
        const words = s.split(/\s+/);
        let wChunk = "";
        for (const w of words) {
          if ((wChunk ? wChunk + " " + w : w).length <= maxLen) {
            wChunk = wChunk ? wChunk + " " + w : w;
          } else {
            if (wChunk) chunks.push(wChunk);
            wChunk = w.slice(0, maxLen);
          }
        }
        current = wChunk;
      } else {
        current = s;
      }
    }
  }
  if (current) chunks.push(current);
  return chunks.filter(c => c.length > 0);
}

// ─── Find the "data" sub-chunk in a WAV buffer ────────────────────────────
function findDataChunk(buf: Buffer): { headerEnd: number } {
  let pos = 12;
  while (pos < buf.length - 8) {
    const id = buf.toString("ascii", pos, pos + 4);
    const size = buf.readUInt32LE(pos + 4);
    if (id === "data") return { headerEnd: pos + 8 };
    pos += 8 + size + (size % 2 !== 0 ? 1 : 0);
  }
  return { headerEnd: 44 }; // fallback: standard PCM header
}

// ─── Concatenate multiple WAV buffers into one ────────────────────────────
function concatenateWav(buffers: Buffer[]): Buffer {
  if (buffers.length === 0) throw new Error("No audio buffers to concatenate");
  if (buffers.length === 1) return buffers[0];

  const { headerEnd: firstDataStart } = findDataChunk(buffers[0]);

  const pcmParts = buffers.map(buf => {
    const { headerEnd } = findDataChunk(buf);
    return buf.slice(headerEnd);
  });

  const totalPcm = pcmParts.reduce((s, b) => s + b.length, 0);

  // Clone the first buffer's header
  const header = Buffer.from(buffers[0].slice(0, firstDataStart));
  // Patch RIFF file size (byte 4): total - 8
  header.writeUInt32LE(header.length + totalPcm - 8, 4);
  // Patch data chunk size (4 bytes before firstDataStart)
  header.writeUInt32LE(totalPcm, firstDataStart - 4);

  return Buffer.concat([header, ...pcmParts]);
}

// ─── TTS endpoint ──────────────────────────────────────────────────────────
router.post("/", async (req, res) => {
  if (!process.env.GROQ_API_KEY) {
    res.status(503).json({ error: "AI service not configured." });
    return;
  }

  const parsed = Body.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Expected { text: string }" });
    return;
  }

  const { text, voice = "hannah" } = parsed.data;
  const chunks = splitChunks(text, 190);

  if (chunks.length === 0) {
    res.status(400).json({ error: "No speakable text." });
    return;
  }

  try {
    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const audioBuffers: Buffer[] = [];

    for (const chunk of chunks) {
      const speech = await (groq.audio.speech.create as Function)({
        model: "canopylabs/orpheus-v1-english",
        input: chunk,
        voice,
        response_format: "wav",
      });

      const buf = Buffer.from(await speech.arrayBuffer());
      if (buf.length > 100) audioBuffers.push(buf);
    }

    if (audioBuffers.length === 0) {
      res.status(500).json({ error: "No audio generated." });
      return;
    }

    const combined = concatenateWav(audioBuffers);
    res.setHeader("Content-Type", "audio/wav");
    res.setHeader("Content-Length", combined.length);
    res.send(combined);
  } catch (err: any) {
    const status: number = err?.status ?? err?.response?.status ?? 0;
    req.log?.error({ err: String(err), status }, "TTS failed");

    if (status === 429) {
      res.status(429).json({ error: "Voice rate limit reached. Browser voice will be used instead." });
    } else {
      res.status(503).json({ error: "Natural voice unavailable. Browser voice will be used instead." });
    }
  }
});

export default router;
