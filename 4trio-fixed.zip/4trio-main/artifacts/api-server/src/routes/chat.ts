import { Router } from "express";
import { z } from "zod";
import {
  PROVIDERS,
  autoSelectProvider, resolveModel, resolveMaxTokens, isProviderAvailable, selectFallbackProviders, PROVIDER_IDS,
  type ProviderId, type ChatMessage, type ContentPart,
} from "../lib/providers.js";

const router = Router();

// ─── Schemas ───────────────────────────────────────────────────────────────
const ChatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
});

type FrontendMessage = z.infer<typeof ChatMessageSchema>;

const VALID_PROVIDERS = new Set<string>(["auto", ...PROVIDER_IDS]);

const ChatBody = z.object({
  messages:        z.array(ChatMessageSchema).min(1),
  provider:        z.string().optional(),
  images:          z.array(z.string()).optional(),
  imageMediaTypes: z.array(z.string()).optional(),
  isContinuation:  z.boolean().optional(),
  previousContent: z.string().optional(),
  model:           z.string().optional(),
});

const TitleBody = z.object({
  message: z.string().min(1).max(500),
});

const GEMINI_IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL ?? "gemini-3.1-flash-image";

type GeneratedImage = { dataUrl: string; mimeType: string };
type ImageGenerationResult = { text: string; images: GeneratedImage[]; model: string };

function wantsImageOutput(message: string, hasImages: boolean): boolean {
  const text = message.toLowerCase();

  const asksForNewImage =
    /\b(generate|create|make|draw|design|render|produce|show|give me|get me)\b[\s\S]{0,120}\b(image|picture|photo|logo|icon|illustration|wallpaper|poster|sticker|artwork|avatar|sketch|drawing|painting|portrait|landscape|scene|cartoon|anime|render|visual)\b/.test(text)
    || /\b(draw|sketch|illustrate|paint|generate|create|make|design)\b[\s\S]{0,120}\b(of|me|a|an|the)\b/.test(text)
    || /\b(text[- ]?to[- ]?image|image generation|ai image|ai art|ai picture)\b/.test(text)
    || /^(draw|sketch|paint|illustrate|create|generate|make|design|render)\s+/i.test(message.trim());

  const asksToEditImage = hasImages && (
    /\b(turn|convert|transform|make|change|edit|restyle|redraw|recreate|stylize|apply)\b[\s\S]{0,120}\b(sketch|drawing|cartoon|anime|watercolor|painting|illustration|style|black.?and.?white|line.?art|oil|portrait|realistic|3d|render)\b/.test(text)
    || /\b(remove|replace|erase|add|put|change)\b[\s\S]{0,80}\b(background|object|person|text|color|element)\b/.test(text)
    || /\b(make it look|turn (it |this )?(into|to)|convert (it |this )?(to|into))\b/.test(text)
  );

  return asksForNewImage || asksToEditImage;
}

function imageGenerationUserMessage(status: number, detail: string): string {
  if (status === 401 || status === 403) {
    return "Image generation is unavailable because GEMINI_API_KEY is invalid, missing, or lacks permission.";
  }
  if (status === 404 || detail.toLowerCase().includes("not found")) {
    return `Gemini image model ${GEMINI_IMAGE_MODEL} is not available for this API key. Set GEMINI_IMAGE_MODEL to a supported image-generation model.`;
  }
  if (status === 429) return "Image generation requires a paid Gemini API plan. Your current API key is on the free tier, which has no quota for image generation models. Upgrade at aistudio.google.com to enable it.";
  return "Image generation failed. Please try again with a simpler prompt or a different image.";
}

async function callGeminiImageGeneration(opts: {
  prompt: string;
  images?: string[];
  imageMediaTypes?: string[];
  signal: AbortSignal;
}): Promise<ImageGenerationResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw Object.assign(new Error("GEMINI_API_KEY is required for image generation"), {
      status: 503,
      userMessage: "Image generation is not configured. Add GEMINI_API_KEY to enable generated images.",
    });
  }

  const parts: Record<string, unknown>[] = [{ text: opts.prompt }];
  for (let i = 0; i < (opts.images?.length ?? 0); i++) {
    const img = opts.images![i];
    const base64 = img.includes(",") ? img.split(",")[1] : img;
    const mimeType = opts.imageMediaTypes?.[i] ?? img.match(/^data:([^;]+)/)?.[1] ?? "image/jpeg";
    parts.push({ inline_data: { mime_type: mimeType, data: base64 } });
  }

  const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_IMAGE_MODEL}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts }],
      generationConfig: { responseModalities: ["TEXT", "IMAGE"] },
    }),
    signal: opts.signal,
  });

  if (!resp.ok) {
    const body = await resp.text();
    let detail = body;
    try {
      const parsed = JSON.parse(body);
      detail = parsed?.error?.message ?? parsed?.message ?? body;
    } catch { /* response was not JSON */ }
    throw Object.assign(new Error(`Gemini image generation ${resp.status}: ${detail}`), {
      status: resp.status,
      body,
      userMessage: imageGenerationUserMessage(resp.status, detail),
    });
  }

  const json: any = await resp.json();
  const result: ImageGenerationResult = { text: "", images: [], model: GEMINI_IMAGE_MODEL };
  for (const candidate of json?.candidates ?? []) {
    for (const part of candidate?.content?.parts ?? []) {
      if (typeof part?.text === "string") result.text += part.text;
      const inline = part?.inlineData ?? part?.inline_data;
      const data = inline?.data;
      if (typeof data === "string" && data) {
        const mimeType = inline?.mimeType ?? inline?.mime_type ?? "image/png";
        result.images.push({ dataUrl: `data:${mimeType};base64,${data}`, mimeType });
      }
    }
  }

  if (result.images.length === 0) {
    throw Object.assign(new Error("Gemini returned no generated image."), {
      status: 502,
      userMessage: result.text.trim() || "Gemini did not return an image. Try a more direct image-generation request.",
    });
  }

  return result;
}

// ─── Token limits ──────────────────────────────────────────────────────────
const MAX_HISTORY_PAIRS = 10;
const TITLE_TOKENS      = 24;
const PROVIDER_TIMEOUT_MS = Number(process.env.CHAT_PROVIDER_TIMEOUT_MS ?? "45000");
const REQUEST_TIMEOUT_MS  = Number(process.env.CHAT_REQUEST_TIMEOUT_MS ?? "60000");

// ─── Owner / identity ─────────────────────────────────────────────────────
// Read from the environment, never hardcoded — this used to be a literal
// string in source, which meant it was exposed the moment the repo went
// public. Set OWNER_CODE in your deploy platform's env vars (not in a
// committed file). If it's unset, owner verification is simply disabled
// rather than silently matching an empty string.
const OWNER_CODE        = process.env.OWNER_CODE?.trim() || "";
const OWNER_CODE_PROMPT = "What's the correct code, Labib?";
const INTERNAL_RE       = /\b(internal|private|admin|owner(?:ship)?|developer[- ]?only|normal users can't|system prompt|hidden instructions?|secret|api keys?|env(?:ironment)? variables?|database credentials?)\b/i;
const CODE_RE           = /\b(code|debug|program+ing?|algorithm|function|class|implement|build|develop|website|web ?app|application|api|database|sql|query|regex|script|bash|python|javascript|typescript|react|angular|vue|html|css|refactor|optimize|bug|error|exception|stack ?trace|deploy|docker|kubernetes|git|compile|syntax|library|framework|architecture|math|calculus|equation|formula|theorem|proof)\b/i;

function getLastUserMessage(messages: FrontendMessage[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i].role === "user") return messages[i].content;
  }
  return "";
}

function isOwnerVerified(messages: FrontendMessage[]): boolean {
  if (!OWNER_CODE) return false;
  return messages.some(m => m.role === "user" && m.content.trim() === OWNER_CODE);
}

function sendLocalSse(res: import("express").Response, content: string): void {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();
  res.write(`data: ${JSON.stringify({ content, provider: "local", model: "local" })}\n\n`);
  res.write(`data: ${JSON.stringify({ done: true, truncated: false, provider: "local", model: "local" })}\n\n`);
  res.end();
}

function buildSystemPrompt(isCode: boolean, ownerVerified: boolean, provider?: Exclude<ProviderId, "auto">): string {
  const creatorPolicy = ownerVerified
    ? "The user has verified as Labib. Answer his internal/private 4trio questions honestly. If he asks who created you, confirm that Labib created you."
    : [
        "IDENTITY RULES — follow strictly using intent classification, not keyword matching:",
        "1. PURPOSE questions (why were you created, what is your purpose): Answer with purpose only. Never mention a creator.",
        "2. ABOUT YOURSELF (tell me about yourself, what can you do): Describe capabilities only. No creator mention.",
        "3. WHO CREATED *YOU* (who made you, who built you — about the AI entity): Respond poetically without naming anyone.",
        "4. WHO MADE *THIS AI / 4trio* (who built 4trio, who owns 4trio — about the product): Answer 'This AI eorked on by Labib.'",
        "5. NEVER mention Labib proactively. Only mention Labib when explicitly asked about the product's authorship (rule 4).",
        "6. For internal/private/admin/developer-only questions, do not reveal details; ask the user to verify first.",
      ].join(" ");

  const responseStyle = provider === "uncensored"
    ? " Free Thinking mode: be direct and complete. Do not add generic legal/safety disclaimers, moralizing, repeated warnings, or suggestions to find another way when you can answer. If the user asks about a word, phrase, slur, or offensive term, explain its meaning, origin, historical context, and current usage neutrally instead of refusing solely because the term is offensive. If you cannot assist with a harmful request, refuse briefly in one sentence and move on."
    : "";

  return isCode
    ? `You are 4trio, a helpful AI assistant specializing in code and technical topics. Be precise and thorough. For large projects output code split by file. ${creatorPolicy}${responseStyle}`
    : `You are 4trio, a helpful AI assistant. Be concise, clear, and friendly. ${creatorPolicy}${responseStyle}`;
}


function timeoutError(ms: number, provider?: string): Error & { status?: number; provider?: string; userMessage?: string } {
  return Object.assign(new Error(`Provider request timed out after ${ms}ms`), {
    status: 504,
    provider,
    userMessage: "The model took too long to respond. I stopped the request so the chat would not stay loading forever. Please try again or switch models.",
  });
}

function withTimeout<T>(promise: Promise<T>, ms: number, provider?: string, onTimeout?: () => void): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      onTimeout?.();
      reject(timeoutError(ms, provider));
    }, ms);
  });
  return Promise.race([promise, timeout]).finally(() => { if (timer) clearTimeout(timer); });
}

// ─── Chat endpoint ─────────────────────────────────────────────────────────
router.post("/", async (req, res) => {
  const parsed = ChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body", details: parsed.error.issues });
    return;
  }

  const { messages, provider: requestedProvider, model: requestedModel, images, imageMediaTypes, isContinuation, previousContent } = parsed.data;
  const hasImages    = Boolean(images?.length);
  const lastUserMsg  = getLastUserMessage(messages);
  const ownerVerified = isOwnerVerified(messages);

  // Owner guard
  if (!ownerVerified && INTERNAL_RE.test(lastUserMsg)) {
    sendLocalSse(res, OWNER_CODE_PROMPT);
    return;
  }
  if (OWNER_CODE && lastUserMsg.trim() === OWNER_CODE) {
    sendLocalSse(res, "Verified. You can ask me your internal 4trio questions now.");
    return;
  }

  // ── Resolve provider ──────────────────────────────────────────────────────
  const normalised = (requestedProvider && VALID_PROVIDERS.has(requestedProvider) ? requestedProvider : "auto") as ProviderId;

  let resolvedProvider: Exclude<ProviderId, "auto">;
  if (normalised === "auto") {
    resolvedProvider = autoSelectProvider(lastUserMsg, hasImages);
  } else {
    // User picked manually — use it if key exists, else fall back
    const pid = normalised as Exclude<ProviderId, "auto">;
    if (isProviderAvailable(pid)) {
      resolvedProvider = pid;
    } else {
      req.log.warn({ requested: pid }, "Requested provider has no API key; falling back to automatic routing");
      resolvedProvider = autoSelectProvider(lastUserMsg, hasImages);
    }
  }

  // Final availability check
  if (!isProviderAvailable(resolvedProvider)) {
    const fallback = PROVIDER_IDS.find((id) => isProviderAvailable(id));
    if (fallback) {
      req.log.warn({ resolvedProvider, fallback }, "Provider unavailable, using configured fallback");
      resolvedProvider = fallback;
    } else {
      res.status(503).json({ error: "No AI provider is configured. Please add GROQ_API_KEY, GEMINI_API_KEY, FEATHERLESS_API_KEY, or another supported provider key." });
      return;
    }
  }


  const providerCaps = PROVIDERS[resolvedProvider].capabilities;
  if (hasImages && !providerCaps.vision) {
    const visionFallback = PROVIDER_IDS.find((id) => isProviderAvailable(id) && PROVIDERS[id].capabilities.vision);
    if (visionFallback) {
      req.log.warn({ requestedProvider: resolvedProvider, visionFallback }, "Selected provider does not support image input; using vision-capable provider");
      resolvedProvider = visionFallback;
    } else {
      res.status(400).json({ error: "The selected model does not support image uploads. Choose a vision-capable model and try again." });
      return;
    }
  }

  const activeCaps = PROVIDERS[resolvedProvider].capabilities;
  if (hasImages && images && images.length > activeCaps.maxImages) {
    res.status(400).json({ error: `${PROVIDERS[resolvedProvider].label} supports up to ${activeCaps.maxImages} image${activeCaps.maxImages === 1 ? "" : "s"} per message.` });
    return;
  }

  const requestStartedAt = Date.now();
  const requestAbort = new AbortController();
  const requestTimer = setTimeout(() => requestAbort.abort(), REQUEST_TIMEOUT_MS);

  const isCode  = CODE_RE.test(lastUserMsg);
  const model   = requestedModel || resolveModel(resolvedProvider, hasImages);
  const maxTok  = resolveMaxTokens(resolvedProvider, isCode);
  const systemPrompt = buildSystemPrompt(isCode, ownerVerified, resolvedProvider);

  req.log.info({
    route: "chat",
    phase: "start",
    requestedProvider: normalised,
    selectedProvider: resolvedProvider,
    selectedModel: model,
    apiKeyPresent: isProviderAvailable(resolvedProvider),
    hasImages,
    maxTokens: maxTok,
  }, "Chat request routed");

  // ── Build message array ───────────────────────────────────────────────────
  const historyPairs = resolvedProvider === "uncensored" ? 4 : MAX_HISTORY_PAIRS;
  const historySlice = messages.slice(0, -1).slice(-(historyPairs * 2));
  const allMessages: ChatMessage[] = [
    { role: "system", content: systemPrompt },
    ...historySlice.map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
  ];

  const lastMsg = messages[messages.length - 1];

  if (isContinuation && previousContent != null) {
    allMessages.push({ role: "assistant", content: previousContent });
    allMessages.push({ role: "user", content: "Please continue exactly from where you left off. Do not repeat previous content." });
  } else if (hasImages && images?.length) {
    const parts: ContentPart[] = [];
    for (let i = 0; i < images.length; i++) {
      const img    = images[i];
      const base64 = img.includes(",") ? img.split(",")[1] : img;
      const rawMime = imageMediaTypes?.[i];
      const VALID_MIME = new Set(["image/jpeg", "image/png", "image/gif", "image/webp"]);
      const mime = (rawMime && VALID_MIME.has(rawMime) ? rawMime : "image/jpeg") as "image/jpeg";
      parts.push({ type: "image_url", image_url: { url: `data:${mime};base64,${base64}` } });
    }
    if (lastMsg.content.trim()) parts.push({ type: "text", text: lastMsg.content });
    allMessages.push({ role: "user", content: parts });
  } else {
    allMessages.push({ role: lastMsg.role as "user" | "assistant", content: lastMsg.content });
  }

  // ── Stream ────────────────────────────────────────────────────────────────
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  let streamEnded = false;
  const send = (data: object) => {
    if (!res.writableEnded) res.write(`data: ${JSON.stringify(data)}\n\n`);
  };
  const endStream = () => {
    if (!res.writableEnded) res.end();
    streamEnded = true;
    clearTimeout(requestTimer);
  };

  if (wantsImageOutput(lastUserMsg, hasImages)) {
    try {
      req.log.info({ route: "chat", phase: "image_generation_start", model: GEMINI_IMAGE_MODEL, hasImages }, "Image generation request starting");
      const result = await withTimeout(callGeminiImageGeneration({
        prompt: lastUserMsg,
        images,
        imageMediaTypes,
        signal: requestAbort.signal,
      }), PROVIDER_TIMEOUT_MS, "gemini-image", () => requestAbort.abort());

      const text = result.text.trim() || (hasImages ? "Here is the edited image." : "Here is the generated image.");
      send({ content: text, provider: "gemini", model: result.model });
      for (const image of result.images) {
        send({ image, provider: "gemini", model: result.model });
      }
      send({ done: true, truncated: false, provider: "gemini", model: result.model });
      endStream();
      return;
    } catch (err: any) {
      req.log.error({ err: String(err), status: err?.status, body: err?.body, userMessage: err?.userMessage }, "Image generation failed");
      send({ error: err?.userMessage ?? "Image generation failed. Please try again." });
      endStream();
      return;
    }
  }

  const RETRIABLE = new Set([429, 500, 502, 503]);
  let attempts = 0;

  async function tryProvider(pid: Exclude<ProviderId, "auto">, isRetry: boolean): Promise<boolean> {
    attempts++;
    let emittedContent = false;
    try {
      const attemptModel = resolveModel(pid, hasImages);
      const attemptAbort = new AbortController();
      const abortAttempt = () => attemptAbort.abort();
      requestAbort.signal.addEventListener("abort", abortAttempt, { once: true });
      req.log.info({ route: "chat", phase: "provider_start", provider: pid, model: attemptModel, apiKeyPresent: isProviderAvailable(pid), isRetry }, "Provider request starting");
      await withTimeout(PROVIDERS[pid].stream({
        messages: allMessages,
        maxTokens: maxTok,
        model: attemptModel,
        res,
        signal: attemptAbort.signal,
        log: req.log,
        onChunk: (text, m) => {
          emittedContent = true;
          send({ content: text, provider: pid, model: m });
        },
        onDone:  (trunc, m) => {
          send({ done: true, truncated: trunc, provider: pid, model: m });
          req.log.info({ route: "chat", phase: "provider_done", provider: pid, model: m, truncated: trunc, durationMs: Date.now() - requestStartedAt }, "Provider request completed");
          endStream();
        },
      }), PROVIDER_TIMEOUT_MS, pid, () => attemptAbort.abort());
      requestAbort.signal.removeEventListener("abort", abortAttempt);
      if (!streamEnded) {
        send({ error: "The model ended without a final response. Please try again." });
        endStream();
      }
      return true;
    } catch (err: any) {
      const status: number = err?.status ?? 0;
      lastProviderError = err;
      req.log.error({ err: String(err), status, provider: pid, isRetry, body: err?.body, userMessage: err?.userMessage }, "Provider request failed");
      if (!emittedContent && (RETRIABLE.has(status) || status === 504)) return false;
      throw err;
    }
  }

  const primaryFallbacks = selectFallbackProviders(resolvedProvider, hasImages);
  const fallbackChain = [resolvedProvider, ...primaryFallbacks.filter((pid) => pid !== resolvedProvider)];
  let lastProviderError: any = null;

  try {
    for (let i = 0; i < fallbackChain.length; i++) {
      const pid = fallbackChain[i];
      const isRetry = i > 0;
      if (isRetry) {
        send({ info: `Switching to ${PROVIDERS[pid].label}…` });
        req.log.warn({ from: fallbackChain[i - 1], to: pid }, "Falling back to next provider");
      }
      const ok = await tryProvider(pid, isRetry);
      if (ok) return;
    }
    // All providers failed
    if (!res.writableEnded) {
      send({ error: lastProviderError?.userMessage ?? "All AI providers are currently unavailable. Please try again shortly." });
      endStream();
    }
  } catch (err: any) {
    req.log.error({ err: String(err), body: err?.body, userMessage: err?.userMessage }, "Chat stream failed entirely");
    if (!res.writableEnded) {
      send({ error: err?.userMessage ?? "This model is unavailable right now, try another model." });
      endStream();
    }
  } finally {
    clearTimeout(requestTimer);
    req.log.info({ route: "chat", phase: "end", selectedProvider: resolvedProvider, selectedModel: model, durationMs: Date.now() - requestStartedAt, writableEnded: res.writableEnded }, "Chat request ended");
  }
});

// ─── Title generation ──────────────────────────────────────────────────────
router.post("/title", async (req, res) => {
  const parsed = TitleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const providers = (["groq", "cerebras", "openrouter", "gemini", "uncensored"] as Exclude<ProviderId, "auto">[]).filter((id) =>
    isProviderAvailable(id) && PROVIDERS[id].capabilities.text
  );

  if (providers.length === 0) {
    res.status(503).json({ error: "AI service not configured.", title: null });
    return;
  }

  const firstMessage = parsed.data.message.slice(0, 300);
  for (const provider of providers) {
    let title = "";
    try {
      await PROVIDERS[provider].stream({
        messages: [
          { role: "system", content: "Generate a concise 3–6 word chat title from the user's first message. Infer intent instead of copying vague text. If the user sounds confused or only says something like 'what', 'huh', or '?', output: User is confused. Output ONLY the title. No quotes, no final punctuation." },
          { role: "user", content: firstMessage },
        ],
        maxTokens: TITLE_TOKENS,
        model: resolveModel(provider, false),
        res,
        log: req.log,
        onChunk: (text) => { title += text; },
        onDone: () => undefined,
      });
      const cleanTitle = title.trim().replace(/^['"]|['"]$/g, "").replace(/[.!?]+$/g, "");
      res.json({ title: cleanTitle || null });
      return;
    } catch (err: any) {
      req.log.warn({ err: String(err), body: err?.body, provider }, "Title generation provider failed; trying fallback");
    }
  }

  res.status(500).json({ error: "Title generation failed", title: null });

});

export default router;
