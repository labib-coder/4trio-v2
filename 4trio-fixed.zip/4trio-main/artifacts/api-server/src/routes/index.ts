import { Router, type IRouter } from "express";
import healthRouter from "./health";
import chatRouter from "./chat";
import authRouter from "./auth";
import transcribeRouter from "./transcribe";
import ttsRouter from "./tts";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/chat", chatRouter);
router.use("/transcribe", transcribeRouter);
router.use("/tts", ttsRouter);

export default router;
