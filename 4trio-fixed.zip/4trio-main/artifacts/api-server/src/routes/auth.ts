import { Router } from "express";

const router = Router();

router.get("/me", (_req, res) => {
  res.status(401).json({ error: "Not authenticated" });
});

router.post("/login", (_req, res) => {
  res.status(404).json({ error: "Login is disabled" });
});

router.post("/register", (_req, res) => {
  res.status(404).json({ error: "Registration is disabled" });
});

router.post("/logout", (_req, res) => {
  res.json({ ok: true });
});

router.patch("/profile", (_req, res) => {
  res.status(404).json({ error: "Not available" });
});

export default router;
