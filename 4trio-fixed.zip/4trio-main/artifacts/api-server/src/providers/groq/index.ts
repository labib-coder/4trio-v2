import type { ProviderConfig, StreamOptions } from "../shared/types.js";

export const GROQ_CHAT_MODEL   = "openai/gpt-oss-20b";
export const GROQ_CODE_MODEL   = "openai/gpt-oss-120b";
export const GROQ_VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct";

async function groqStream(opts: StreamOptions): Promise<void> {
  const { default: Groq } = await import("groq-sdk");
  const groq = new Groq({ apiKey: process.env.GROQ_API_KEY! });
  const model = opts.model ?? GROQ_CHAT_MODEL;

  const stream = await (groq.chat.completions.create as Function)({
    model,
    messages: opts.messages,
    stream: true,
    max_completion_tokens: opts.maxTokens,
  }, opts.signal ? { signal: opts.signal } : undefined);

  let truncated = false;
  for await (const chunk of stream) {
    const text: string = chunk.choices[0]?.delta?.content ?? "";
    if (text) opts.onChunk(text, model);
    if (chunk.choices[0]?.finish_reason === "length") truncated = true;
  }
  opts.onDone(truncated, model);
}

export const groqProvider: ProviderConfig = {
  id: "groq",
  label: "Groq",
  envKey: "GROQ_API_KEY",
  defaultModel: GROQ_CHAT_MODEL,
  models: [
    { id: GROQ_CHAT_MODEL, label: "GPT OSS 20B", tags: ["text", "fast"] },
    { id: GROQ_CODE_MODEL, label: "GPT OSS 120B", tags: ["code", "reasoning"] },
    { id: GROQ_VISION_MODEL, label: "Llama 4 Scout", tags: ["vision"], capabilities: { vision: true, maxImages: 5 } },
  ],
  capabilities: {
    text: true,
    vision: true,
    imageGeneration: false,
    voiceReadAloud: true,
    maxImages: 5,
    maxTokens: 2500,
    contextWindow: 131072,
  },
  stream: groqStream,
};
