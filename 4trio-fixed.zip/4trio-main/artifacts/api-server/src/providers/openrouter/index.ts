import { asTextOnlyMessages, readOpenAISseStream, readProviderError } from "../shared/openai-compatible.js";
import type { ProviderConfig, StreamOptions } from "../shared/types.js";

export const OPENROUTER_MODEL = process.env.OPENROUTER_CHAT_MODEL ?? "openai/gpt-oss-120b:free";

type ProviderRuntimeMetadata = { badge?: string | null; desc?: string; routePriority?: number };

function withOpenRouterUserMessage(error: Error & { status?: number; body?: string; provider?: string }) {
  const status = error.status ?? 0;
  const userMessage = status === 401 || status === 403
    ? "OpenRouter is unavailable because OPENROUTER_API_KEY is invalid, missing, or does not have permission."
    : status === 429
      ? "OpenRouter is rate limited right now. Please wait a moment and try again."
      : status >= 500 || status === 0
        ? "OpenRouter is unavailable right now. Please try again shortly."
        : `OpenRouter rejected the request: ${error.message.slice(0, 220)}`;
  return Object.assign(error, { provider: "openrouter", userMessage });
}

async function openrouterStream(opts: StreamOptions): Promise<void> {
  const model = opts.model ?? OPENROUTER_MODEL;
  let resp: globalThis.Response;
  try {
    resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "HTTP-Referer": process.env.APP_PUBLIC_URL ?? "http://localhost:8080",
        "X-Title": process.env.APP_NAME ?? "4trio",
      },
      signal: opts.signal,
      body: JSON.stringify({
        model,
        messages: asTextOnlyMessages(opts.messages),
        stream: true,
        max_tokens: opts.maxTokens,
      }),
    });
  } catch (err) {
    throw withOpenRouterUserMessage(Object.assign(new Error(`OpenRouter network request failed: ${String(err)}`), { status: 502, provider: "openrouter" }));
  }

  if (!resp.ok) throw withOpenRouterUserMessage(await readProviderError(resp, "OpenRouter"));
  await readOpenAISseStream(resp, model, opts);
}

export const openrouterProvider: ProviderConfig & ProviderRuntimeMetadata = {
  id: "openrouter",
  label: "OpenRouter",
  badge: null,
  desc: "Universal model router for compatible text models.",
  routePriority: 30,
  models: [{ id: OPENROUTER_MODEL, label: "OpenRouter Free", tags: ["text"] }],
  envKey: "OPENROUTER_API_KEY",
  defaultModel: OPENROUTER_MODEL,
  capabilities: { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 4000, contextWindow: 131072 },
  stream: openrouterStream,
};
