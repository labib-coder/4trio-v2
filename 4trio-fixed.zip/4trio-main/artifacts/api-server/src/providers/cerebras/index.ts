import { asTextOnlyMessages, readOpenAISseStream, readProviderError } from "../shared/openai-compatible.js";
import type { ProviderConfig, StreamOptions } from "../shared/types.js";

export const CEREBRAS_MODEL = process.env.CEREBRAS_CHAT_MODEL ?? "gpt-oss-120b";

type ProviderRuntimeMetadata = { badge?: string | null; desc?: string; routePriority?: number };

function withCerebrasUserMessage(error: Error & { status?: number; body?: string; provider?: string }) {
  const status = error.status ?? 0;
  const userMessage = status === 401 || status === 403
    ? "Cerebras is unavailable because CEREBRAS_API_KEY is invalid, missing, or does not have permission."
    : status === 429
      ? "Cerebras is rate limited right now. Please wait a moment and try again."
      : status >= 500 || status === 0
        ? "Cerebras is unavailable right now. Please try again shortly."
        : `Cerebras rejected the request: ${error.message.slice(0, 220)}`;
  return Object.assign(error, { provider: "cerebras", userMessage });
}

async function cerebrasStream(opts: StreamOptions): Promise<void> {
  const model = opts.model ?? CEREBRAS_MODEL;
  let resp: globalThis.Response;
  try {
    resp = await fetch("https://api.cerebras.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.CEREBRAS_API_KEY}`,
      },
      signal: opts.signal,
      body: JSON.stringify({
        model,
        messages: asTextOnlyMessages(opts.messages),
        stream: true,
        max_completion_tokens: opts.maxTokens,
      }),
    });
  } catch (err) {
    throw withCerebrasUserMessage(Object.assign(new Error(`Cerebras network request failed: ${String(err)}`), { status: 502, provider: "cerebras" }));
  }

  if (!resp.ok) throw withCerebrasUserMessage(await readProviderError(resp, "Cerebras"));
  await readOpenAISseStream(resp, model, opts);
}

export const cerebrasProvider: ProviderConfig & ProviderRuntimeMetadata = {
  id: "cerebras",
  label: "Cerebras",
  badge: null,
  desc: "Best for coding, math, and detailed technical responses.",
  routePriority: 10,
  models: [{ id: CEREBRAS_MODEL, label: "Cerebras GPT OSS 120B", tags: ["text", "code"] }],
  envKey: "CEREBRAS_API_KEY",
  defaultModel: CEREBRAS_MODEL,
  capabilities: { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 4000, contextWindow: 131072 },
  stream: cerebrasStream,
};
