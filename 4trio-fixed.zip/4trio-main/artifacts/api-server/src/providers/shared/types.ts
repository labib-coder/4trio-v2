import type { Response } from "express";

export type ProviderId = "auto" | "groq" | "gemini" | "cerebras" | "openrouter" | "uncensored";

export type ProviderCapabilityKey = "text" | "vision" | "imageGeneration" | "voiceReadAloud";

export interface ProviderCapabilities {
  text: boolean;
  vision: boolean;
  imageGeneration: boolean;
  voiceReadAloud: boolean;
  maxImages: number;
  maxTokens: number;
  contextWindow: number;
}

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string | ContentPart[];
}

export interface ContentPart {
  type: "text" | "image_url";
  text?: string;
  image_url?: { url: string };
}

export interface StreamOptions {
  messages: ChatMessage[];
  maxTokens: number;
  model?: string;
  res: Response;
  signal?: AbortSignal;
  onChunk: (text: string, model: string) => void;
  onDone: (truncated: boolean, model: string) => void;
  log: { error: (obj: object, msg?: string) => void; warn: (obj: object, msg?: string) => void; info?: (obj: object, msg?: string) => void };
}

export interface ProviderError extends Error {
  status?: number;
  provider?: string;
  body?: string;
}

export interface ProviderModel {
  id: string;
  label?: string;
  tags?: string[];
  capabilities?: Partial<ProviderCapabilities>;
}

export interface ProviderConfig {
  id: Exclude<ProviderId, "auto">;
  label: string;
  envKey: string;
  defaultModel: string;
  baseUrl?: string;
  models?: ProviderModel[];
  capabilities: ProviderCapabilities;
  stream: (opts: StreamOptions) => Promise<void>;
}
