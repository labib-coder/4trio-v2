import type { ChatMessage, StreamOptions } from "./types.js";

export async function readOpenAISseStream(
  resp: globalThis.Response,
  model: string,
  opts: StreamOptions,
): Promise<void> {
  const reader = resp.body!.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let truncated = false;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const json = line.slice(5).trim();
      if (!json || json === "[DONE]") continue;
      try {
        const parsed = JSON.parse(json);
        const text: string = parsed?.choices?.[0]?.delta?.content ?? "";
        if (text) opts.onChunk(text, model);
        if (parsed?.choices?.[0]?.finish_reason === "length") truncated = true;
      } catch { /* skip malformed SSE lines */ }
    }
  }
  opts.onDone(truncated, model);
}

export function asTextOnlyMessages(messages: ChatMessage[]): Array<{ role: string; content: string }> {
  return messages.map((m) => ({
    role: m.role,
    content: typeof m.content === "string"
      ? m.content
      : m.content.map((part) => part.type === "text" ? part.text ?? "" : "[image omitted: model does not support image input]").join("\n"),
  }));
}

export async function readProviderError(resp: globalThis.Response, provider: string): Promise<Error & { status?: number; body?: string; provider?: string }> {
  const body = await resp.text();
  let message = `${provider} ${resp.status}: ${body}`;
  try {
    const parsed = JSON.parse(body);
    message = parsed?.error?.message ?? parsed?.message ?? message;
  } catch { /* body was not JSON */ }
  return Object.assign(new Error(message), { status: resp.status, body, provider });
}
