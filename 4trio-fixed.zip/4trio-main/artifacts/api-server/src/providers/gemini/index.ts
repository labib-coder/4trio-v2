import type { ContentPart, ProviderConfig, StreamOptions } from "../shared/types.js";

const GEMINI_MODEL = process.env.GEMINI_CHAT_MODEL ?? "gemini-2.0-flash";
const GEMINI_CONTEXT_WINDOW = 1_048_576;
const GEMINI_OUTPUT_TOKEN_LIMIT = 8_192;

type ProviderRuntimeMetadata = { badge?: string | null; desc?: string; routePriority?: number };

function clampGeminiMaxTokens(value: string | undefined): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return GEMINI_OUTPUT_TOKEN_LIMIT;
  return Math.min(Math.floor(parsed), GEMINI_OUTPUT_TOKEN_LIMIT);
}

function toGeminiPart(part: ContentPart): Record<string, unknown> {
  if (part.type === "text") return { text: part.text ?? "" };
  if (part.type === "image_url" && part.image_url?.url) {
    const [header, data] = part.image_url.url.split(",");
    const mimeType = header.match(/data:([^;]+)/)?.[1] ?? "image/jpeg";
    return { inline_data: { mime_type: mimeType, data } };
  }
  return { text: "" };
}

function geminiUserMessage(status: number, detail: string, model: string): string {
  const lower = detail.toLowerCase();
  if (status === 401 || status === 403 || (status === 400 && lower.includes("api key"))) {
    return "Gemini is unavailable because GEMINI_API_KEY is invalid, missing, or does not have permission.";
  }
  if (status === 404 || (status === 400 && (lower.includes("not found") || lower.includes("not supported") || lower.includes("model")))) {
    return `Gemini model ${model} is not available for this API key. Set GEMINI_CHAT_MODEL to a supported Gemini model and try again.`;
  }
  if (status === 429) {
    return "Gemini is rate limited right now. Please wait a moment and try again.";
  }
  if (status >= 500) {
    return "Gemini is unavailable right now. Please try again shortly.";
  }
  return `Gemini rejected the request: ${detail.slice(0, 220)}`;
}

async function geminiError(resp: globalThis.Response, model: string): Promise<Error & { status?: number; body?: string; provider?: string; userMessage?: string }> {
  const body = await resp.text();
  let detail = body;
  try {
    const parsed = JSON.parse(body);
    detail = parsed?.error?.message ?? parsed?.message ?? body;
  } catch { /* response was not JSON */ }

  return Object.assign(new Error(`Gemini ${resp.status}: ${detail}`), {
    status: resp.status,
    body,
    provider: "gemini",
    userMessage: geminiUserMessage(resp.status, detail, model),
  });
}

async function geminiStream(opts: StreamOptions): Promise<void> {
  const model = opts.model ?? GEMINI_MODEL;
  const apiKey = process.env.GEMINI_API_KEY!;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`;

  const systemMsg = opts.messages.find(m => m.role === "system");
  const history = opts.messages.filter(m => m.role !== "system");

  const contents = history.map(m => {
    const role = m.role === "assistant" ? "model" : "user";
    const parts = typeof m.content === "string"
      ? [{ text: m.content }]
      : (m.content as ContentPart[]).map(toGeminiPart).filter(Boolean);
    return { role, parts };
  });

  const body: Record<string, unknown> = {
    contents,
    generationConfig: { maxOutputTokens: Math.min(opts.maxTokens, GEMINI_OUTPUT_TOKEN_LIMIT) },
  };
  if (systemMsg && typeof systemMsg.content === "string") {
    body.systemInstruction = { parts: [{ text: systemMsg.content }] };
  }

  opts.log.info?.({ provider: "gemini", model, maxOutputTokens: Math.min(opts.maxTokens, GEMINI_OUTPUT_TOKEN_LIMIT) }, "Sending Gemini request");

  let resp: globalThis.Response;
  try {
    resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify(body),
      signal: opts.signal,
    });
  } catch (err) {
    throw Object.assign(new Error(`Gemini network request failed: ${String(err)}`), {
      status: 502,
      provider: "gemini",
      userMessage: "Gemini could not be reached from the server. Check outbound network access and GEMINI_API_KEY, then try again.",
    });
  }

  if (!resp.ok) throw await geminiError(resp, model);

  const reader = resp.body!.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let truncated = false;
  let emittedText = false;
  let blockedReason = "";

  const processLine = (line: string) => {
    if (!line.startsWith("data:")) return;
    const json = line.slice(5).trim();
    if (!json || json === "[DONE]") return;
    try {
      const parsed = JSON.parse(json);
      const candidate = parsed?.candidates?.[0];
      const text: string = candidate?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
      if (text) {
        emittedText = true;
        opts.onChunk(text, model);
      }
      const finishReason = candidate?.finishReason;
      if (finishReason === "MAX_TOKENS") truncated = true;
      if (!blockedReason && typeof finishReason === "string" && !["STOP", "MAX_TOKENS"].includes(finishReason)) {
        blockedReason = finishReason;
      }
      if (!blockedReason && parsed?.promptFeedback?.blockReason) {
        blockedReason = String(parsed.promptFeedback.blockReason);
      }
    } catch (err) {
      opts.log.warn({ provider: "gemini", err: String(err), line: line.slice(0, 300) }, "Skipped malformed Gemini SSE line");
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) processLine(line);
  }
  if (buf.trim()) processLine(buf.trim());

  if (!emittedText && blockedReason) {
    throw Object.assign(new Error(`Gemini returned no text. Finish/block reason: ${blockedReason}`), {
      status: 502,
      provider: "gemini",
      userMessage: `Gemini did not return text for this request (${blockedReason}). Try rephrasing or pick another model.`,
    });
  }
  if (!emittedText) {
    throw Object.assign(new Error("Gemini returned an empty streamed response."), {
      status: 502,
      provider: "gemini",
      userMessage: "Gemini returned an empty response. Please try again or pick another model.",
    });
  }

  opts.onDone(truncated, model);
}

export const geminiProvider: ProviderConfig & ProviderRuntimeMetadata = {
  id: "gemini",
  label: "Gemini",
  badge: null,
  desc: "Strong multimodal model for image understanding and long context.",
  routePriority: 20,
  models: [{ id: GEMINI_MODEL, label: "Gemini Flash", tags: ["text", "vision"], capabilities: { vision: true, maxImages: 16 } }],
  envKey: "GEMINI_API_KEY",
  defaultModel: GEMINI_MODEL,
  capabilities: {
    text: true,
    vision: true,
    imageGeneration: true,
    voiceReadAloud: true,
    maxImages: 16,
    maxTokens: clampGeminiMaxTokens(process.env.GEMINI_MAX_OUTPUT_TOKENS),
    contextWindow: GEMINI_CONTEXT_WINDOW,
  },
  stream: geminiStream,
};
