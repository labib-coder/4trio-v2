import { asTextOnlyMessages, readOpenAISseStream } from "../shared/openai-compatible.js";
import type { ProviderConfig, StreamOptions } from "../shared/types.js";

const FEATHERLESS_DEFAULT_BASE_URL = "https://api.featherless.ai/v1";
const FEATHERLESS_FALLBACK_MODEL = "failspy/Meta-Llama-3-8B-Instruct-abliterated-v3";
const MODEL_CACHE_MS = 15 * 60 * 1000;

interface FeatherlessModelInfo {
  id: string;
  name?: string;
  model_class?: string;
  context_length?: number;
  max_completion_tokens?: number;
  is_gated?: boolean;
  available_on_current_plan?: boolean;
  parameter_bucket?: string;
  capabilities?: string[];
  status?: string;
}

let cachedModel: { id: string; expiresAt: number } | null = null;

function featherlessApiKey(): string | undefined {
  return process.env.FEATHERLESS_API_KEY;
}

function featherlessBaseUrl(): string {
  return (process.env.FEATHERLESS_BASE_URL ?? FEATHERLESS_DEFAULT_BASE_URL).replace(/\/$/, "");
}

function configuredModel(): string | undefined {
  return process.env.FEATHERLESS_CHAT_MODEL?.trim() || undefined;
}

function modelCandidatesFromEnv(): string[] {
  const raw = process.env.FEATHERLESS_MODEL_CANDIDATES;
  if (!raw) return [];
  return raw.split(",").map((m) => m.trim()).filter(Boolean);
}


function childSignal(parent: AbortSignal | undefined, ms: number): { signal: AbortSignal; cleanup: () => void } {
  const controller = new AbortController();
  const abort = () => controller.abort();
  const timer = setTimeout(abort, ms);
  if (parent?.aborted) controller.abort();
  else parent?.addEventListener("abort", abort, { once: true });
  return {
    signal: controller.signal,
    cleanup: () => {
      clearTimeout(timer);
      parent?.removeEventListener("abort", abort);
    },
  };
}

function scoreModel(model: FeatherlessModelInfo): number {
  const id = model.id.toLowerCase();
  const bucket = model.parameter_bucket?.toLowerCase() ?? "";
  const modelClass = model.model_class?.toLowerCase() ?? "";
  let score = 0;

  if (model.available_on_current_plan === true) score += 1000;
  if (model.is_gated === false) score += 300;
  if (model.status === "live" || model.status === "available") score += 100;
  if (model.capabilities?.includes("chat")) score += 200;

  // Balance capability and latency: prefer modern 8B-14B chat models, avoid huge models for simple chat.
  if (/14b|12b/.test(id + bucket + modelClass)) score += 280;
  if (/8b|7b/.test(id + bucket + modelClass)) score += 260;
  if (/32b/.test(id + bucket + modelClass)) score += 120;
  if (/70b|72b|405b|671b/.test(id + bucket + modelClass)) score -= 250;

  if (/qwen3|llama-3\.1|llama-3|mistral|hermes|dolphin|abliterated|magnum|margnum/.test(id)) score += 120;
  if (/instruct|chat/.test(id)) score += 100;
  if (/vision|embedding|rerank|audio|whisper|tts|image/.test(id)) score -= 500;

  score += Math.min(model.context_length ?? 0, 32768) / 512;
  score += Math.min(model.max_completion_tokens ?? 0, 4096) / 128;
  return score;
}

async function listAvailableModels(apiKey: string, log: StreamOptions["log"], signal?: AbortSignal): Promise<FeatherlessModelInfo[]> {
  const url = `${featherlessBaseUrl()}/models?available_on_current_plan=true&capabilities=chat&sort=-popularity&page=1&per_page=100`;
  const timeout = childSignal(signal, 2500);
  try {
    const resp = await fetch(url, {
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      signal: timeout.signal,
    });
    if (!resp.ok) {
      log.warn({ status: resp.status, body: await resp.text() }, "Could not list Featherless.ai models; using configured fallback");
      return [];
    }
    const parsed = await resp.json() as { data?: FeatherlessModelInfo[] };
    return Array.isArray(parsed.data) ? parsed.data : [];
  } catch (err) {
    log.warn({ err: String(err) }, "Could not list Featherless.ai models; using configured fallback");
    return [];
  } finally {
    timeout.cleanup();
  }
}

async function probeModel(apiKey: string, model: string, log: StreamOptions["log"], signal?: AbortSignal): Promise<boolean> {
  if (process.env.FEATHERLESS_PROBE_MODELS === "false") return true;
  const timeout = childSignal(signal, 1500);
  try {
    const resp = await fetch(`${featherlessBaseUrl()}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "HTTP-Referer": process.env.APP_PUBLIC_URL ?? "http://localhost:8080",
        "X-Title": process.env.APP_NAME ?? "4trio",
      },
      signal: timeout.signal,
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "Reply with exactly: ok" },
          { role: "user", content: "ok" },
        ],
        stream: false,
        max_tokens: 2,
        temperature: 0,
      }),
    });
    if (resp.ok) return true;
    log.warn({ model, status: resp.status, body: await resp.text() }, "Featherless.ai model probe failed");
    return false;
  } catch (err) {
    log.warn({ model, err: String(err) }, "Featherless.ai model probe failed");
    return false;
  } finally {
    timeout.cleanup();
  }
}

async function resolveFeatherlessModel(apiKey: string, log: StreamOptions["log"], signal?: AbortSignal): Promise<string> {
  const configured = configuredModel();
  if (configured) return configured;
  if (cachedModel && cachedModel.expiresAt > Date.now()) return cachedModel.id;

  const listed = await listAvailableModels(apiKey, log, signal);
  const listedCandidates = listed
    .filter((model) => model.id && model.is_gated !== true && model.available_on_current_plan !== false)
    .sort((a, b) => scoreModel(b) - scoreModel(a))
    .map((model) => model.id);

  const candidates = Array.from(new Set([
    ...modelCandidatesFromEnv(),
    ...listedCandidates,
    FEATHERLESS_FALLBACK_MODEL,
  ]));

  for (const candidate of candidates.slice(0, 4)) {
    if (await probeModel(apiKey, candidate, log, signal)) {
      cachedModel = { id: candidate, expiresAt: Date.now() + MODEL_CACHE_MS };
      log.warn({ model: candidate }, "Selected Featherless.ai model for Free Thinking");
      return candidate;
    }
  }

  return FEATHERLESS_FALLBACK_MODEL;
}

function withUserMessage(error: Error, status: number, body?: string): Error & { status?: number; body?: string; provider?: string; userMessage?: string } {
  const userMessage = status === 429
    ? "Free Thinking is busy right now. Please wait a moment and try again."
    : status === 401 || status === 403
      ? "Free Thinking is unavailable because the Featherless.ai API key is invalid, missing, or does not have permission."
      : "Free Thinking is unavailable right now. Please wait a moment and try again.";
  return Object.assign(error, { status, body, provider: "uncensored", userMessage });
}

async function featherlessError(resp: globalThis.Response): Promise<Error & { status?: number; body?: string; provider?: string; userMessage?: string }> {
  const body = await resp.text();
  let detail = body;
  try {
    const parsed = JSON.parse(body);
    detail = parsed?.error?.message ?? parsed?.message ?? body;
  } catch { /* body was not JSON */ }

  let msg = `Featherless.ai ${resp.status}: ${detail}`;
  if (resp.status === 401 || resp.status === 403) {
    msg = "Featherless.ai API key is invalid, missing, or lacks permission. Check FEATHERLESS_API_KEY.";
  } else if (resp.status === 429) {
    msg = "Featherless.ai rate limit reached.";
  } else if (resp.status === 402) {
    msg = `Featherless.ai billing error: ${detail}`;
  }
  return withUserMessage(new Error(msg), resp.status, body);
}

async function readOpenAIJsonResponse(resp: globalThis.Response, model: string, opts: StreamOptions): Promise<void> {
  const body = await resp.text();
  let parsed: any;
  try {
    parsed = JSON.parse(body);
  } catch {
    throw withUserMessage(new Error(`Featherless.ai returned a non-JSON response: ${body.slice(0, 300)}`), 502, body);
  }

  const text = parsed?.choices?.[0]?.message?.content ?? parsed?.choices?.[0]?.text ?? "";
  if (!text || typeof text !== "string") {
    throw withUserMessage(new Error(`Featherless.ai returned an empty response: ${body.slice(0, 500)}`), 502, body);
  }

  opts.onChunk(text, model);
  opts.onDone(parsed?.choices?.[0]?.finish_reason === "length", model);
}

async function featherlessStream(opts: StreamOptions): Promise<void> {
  const apiKey = featherlessApiKey();
  if (!apiKey) {
    throw Object.assign(new Error("Featherless.ai API key is not configured."), {
      status: 503,
      provider: "uncensored",
      userMessage: "Free Thinking is unavailable because FEATHERLESS_API_KEY is not configured on the server.",
    });
  }

  const model = opts.model && opts.model !== FEATHERLESS_FALLBACK_MODEL
    ? opts.model
    : await resolveFeatherlessModel(apiKey, opts.log, opts.signal);
  const useStreaming = process.env.FEATHERLESS_STREAMING !== "false";
  opts.log.warn({ provider: "featherless", model, baseUrl: featherlessBaseUrl(), streaming: useStreaming }, "Using Featherless.ai provider for Free Thinking");

  const resp = await fetch(`${featherlessBaseUrl()}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": useStreaming ? "text/event-stream, application/json" : "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "HTTP-Referer": process.env.APP_PUBLIC_URL ?? "http://localhost:8080",
      "X-Title": process.env.APP_NAME ?? "4trio",
    },
    signal: opts.signal,
    body: JSON.stringify({
      model,
      messages: asTextOnlyMessages(opts.messages),
      stream: useStreaming,
      max_tokens: opts.maxTokens,
      temperature: 0.7,
      top_p: 0.9,
    }),
  });

  if (!resp.ok) throw await featherlessError(resp);

  if (useStreaming && resp.headers.get("content-type")?.includes("text/event-stream")) {
    await readOpenAISseStream(resp, model, opts);
    return;
  }

  await readOpenAIJsonResponse(resp, model, opts);
}

export const featherlessProvider: ProviderConfig = {
  id: "uncensored",
  label: "Free Thinking (Featherless.ai)",
  envKey: "FEATHERLESS_API_KEY",
  defaultModel: configuredModel() ?? FEATHERLESS_FALLBACK_MODEL,
  baseUrl: featherlessBaseUrl(),
  models: [{ id: configuredModel() ?? FEATHERLESS_FALLBACK_MODEL, label: "Free Thinking", tags: ["text", "unrestricted"] }],
  capabilities: { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 512, contextWindow: 8192 },
  stream: featherlessStream,
};
