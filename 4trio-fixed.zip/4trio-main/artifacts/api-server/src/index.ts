import app from "./app";
import { logger } from "./lib/logger";
import { PROVIDERS } from "./lib/providers";
import { scheduleStartupProbes } from "./lib/model-health";

const port = Number(process.env.PORT ?? "8080");
const host = "0.0.0.0";

const server = app.listen(port, host, () => {
  logger.info({ port, host }, "Server listening");
  // Non-blocking: fire model health probes after server is accepting requests
  scheduleStartupProbes(Object.values(PROVIDERS));
});

server.on("error", (err) => {
  logger.error({ err }, "Server error");
  process.exit(1);
});
