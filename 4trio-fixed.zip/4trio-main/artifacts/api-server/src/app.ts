import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
      },
      res(res) {
        return { statusCode: res.statusCode };
      },
    },
  }),
);

// CORS — set ALLOWED_ORIGINS=https://yourdomain.com in production (comma-separated).
// Leave unset to allow all origins (fine for Replit dev and single-origin deploys).
// Credentials are only enabled when specific origins are configured — reflecting
// any origin (origin: true) while also allowing credentials is unsafe, so the
// unset/wildcard case keeps credentials off.
const allowedOriginsEnv = process.env.ALLOWED_ORIGINS;
const corsOptions: cors.CorsOptions = allowedOriginsEnv
  ? { origin: allowedOriginsEnv.split(",").map(s => s.trim()).filter(Boolean), credentials: true }
  : { origin: true, credentials: false };
app.use(cors(corsOptions));
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));

app.use("/api", router);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (process.env.NODE_ENV === "production") {
  const frontendDist = path.resolve(
    __dirname,
    "../../../artifacts/4trio/dist",
  );

  app.use(express.static(frontendDist));

  app.get(/.*/, (_req, res) => {
    res.sendFile(path.join(frontendDist, "index.html"));
  });
}

export default app;
