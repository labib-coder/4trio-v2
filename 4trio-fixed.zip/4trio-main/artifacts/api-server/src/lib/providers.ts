import { groqProvider, GROQ_CHAT_MODEL, GROQ_CODE_MODEL, GROQ_VISION_MODEL } from "../providers/groq/index.js";
import { geminiProvider } from "../providers/gemini/index.js";
import { cerebrasProvider } from "../providers/cerebras/index.js";
import { openrouterProvider } from "../providers/openrouter/index.js";
import { featherlessProvider } from "../providers/featherless/index.js";
import type { ChatMessage, ContentPart, ProviderConfig, ProviderId } from "../providers/shared/types.js";

export { GROQ_CHAT_MODEL, GROQ_CODE_MODEL, GROQ_VISION_MODEL };
export type { ChatMessage, ContentPart, ProviderConfig, ProviderId };

type RuntimeProviderMetadata = Partial<{
  badge: string | null;
  desc: string;
  health: unknown;
  startupProbe: unknown;
  routePriority: number;
  models: ProviderConfig["models"];
}>;

type RuntimeProviderHealth = Partial<{
  healthy: boolean;
  available: boolean;
  latencyMs: number | null;
  checkedAt: string | number | null;
  error: string | null;
}>;

export const PROVIDERS: Record<Exclude<ProviderId, "auto">, ProviderConfig> = {
  groq: groqProvider,
  gemini: geminiProvider,
  cerebras: cerebrasProvider,
  openrouter: openrouterProvider,
  uncensored: featherlessProvider,
};

export const PROVIDER_IDS = Object.keys(PROVIDERS) as Array<Exclude<ProviderId, "auto">>;

function runtimeMetadata(id: Exclude<ProviderId, "auto">): RuntimeProviderMetadata {
  return PROVIDERS[id] as ProviderConfig & RuntimeProviderMetadata;
}

function runtimeHealth(id: Exclude<ProviderId, "auto">): RuntimeProviderHealth {
  const meta = runtimeMetadata(id);
  const raw = meta.health ?? meta.startupProbe;
  return raw && typeof raw === "object" ? raw as RuntimeProviderHealth : {};
}

function isRuntimeHealthy(id: Exclude<ProviderId, "auto">): boolean {
  const health = runtimeHealth(id);
  if (health.available === false || health.healthy === false) return false;
  return true;
}

export function isProviderAvailable(id: Exclude<ProviderId, "auto">): boolean {
  return Boolean(process.env[PROVIDERS[id].envKey]) && isRuntimeHealthy(id);
}

export function getProviderStatus() {
  return Object.fromEntries(
    PROVIDER_IDS.map((id) => {
      const provider = PROVIDERS[id];
      const meta = runtimeMetadata(id);
      const health = runtimeHealth(id);
      return [id, {
        configured: Boolean(process.env[provider.envKey]),
        available: isProviderAvailable(id),
        healthy: health.healthy ?? health.available ?? isRuntimeHealthy(id),
        latencyMs: health.latencyMs ?? null,
        checkedAt: health.checkedAt ?? null,
        error: health.error ?? null,
        label: provider.label,
        badge: meta.badge ?? null,
        desc: meta.desc,
        defaultModel: provider.defaultModel,
        models: provider.models,
        routePriority: meta.routePriority,
        capabilities: provider.capabilities,
      }];
    }),
  );
}

const CODE_RE = /\b(code|debug|program+ing?|algorithm|function|class|implement|build|develop|website|web ?app|application|api|database|sql|query|regex|script|bash|python|javascript|typescript|react|angular|vue|html|css|refactor|optimize|bug|error|exception|stack ?trace|deploy|docker|kubernetes|git|compile|syntax|library|framework|architecture|math|calculus|equation|formula|theorem|proof)\b/i;
const LONG_RE = /\b(analyze|explain in detail|compare|contrast|evaluate|critique|pros and cons|trade[- ]?off|best approach|recommend|strategy|comprehensive|in[- ]depth|step[- ]by[- ]step|elaborate|essay|report|summarize this|long)\b/i;

function byRoutePriority(ids: Array<Exclude<ProviderId, "auto">>): Array<Exclude<ProviderId, "auto">> {
  return [...ids].sort((a, b) => (runtimeMetadata(a).routePriority ?? 0) - (runtimeMetadata(b).routePriority ?? 0));
}

function firstAvailable(ids: Array<Exclude<ProviderId, "auto">>): Exclude<ProviderId, "auto"> | null {
  return byRoutePriority(ids).find((id) => isProviderAvailable(id)) ?? null;
}

export function autoSelectProvider(lastUserMsg: string, hasImages: boolean): Exclude<ProviderId, "auto"> {
  if (hasImages) {
    return firstAvailable(PROVIDER_IDS.filter((id) => PROVIDERS[id].capabilities.vision))
      ?? firstAvailable(PROVIDER_IDS)
      ?? "groq";
  }

  if (CODE_RE.test(lastUserMsg) || LONG_RE.test(lastUserMsg)) {
    return firstAvailable(["cerebras", "gemini", "openrouter", "groq"])
      ?? firstAvailable(PROVIDER_IDS)
      ?? "groq";
  }

  return firstAvailable(["groq", "gemini", "openrouter", "cerebras"])
    ?? firstAvailable(PROVIDER_IDS)
    ?? "groq";
}

export function resolveModel(provider: Exclude<ProviderId, "auto">, hasImages: boolean): string {
  if (provider === "groq" && hasImages) return GROQ_VISION_MODEL;
  return PROVIDERS[provider].defaultModel;
}

export function resolveMaxTokens(provider: Exclude<ProviderId, "auto">, isCode: boolean): number {
  const cap = PROVIDERS[provider].capabilities.maxTokens;
  return isCode ? cap : Math.min(cap, 2000);
}

export function selectFallbackProviders(primary: Exclude<ProviderId, "auto">, hasImages: boolean): Array<Exclude<ProviderId, "auto">> {
  const candidates = PROVIDER_IDS.filter((id) => id !== primary && isProviderAvailable(id));
  const compatible = hasImages ? candidates.filter((id) => PROVIDERS[id].capabilities.vision) : candidates;
  return [primary, ...byRoutePriority(compatible).filter((id) => id !== "uncensored")];
}
