/**
 * model-health.ts — Startup model probe system.
 *
 * Probes every configured model with a lightweight request after the server
 * starts. Results are stored in-memory for routing and the health endpoint.
 *
 * Status semantics:
 *   "ok"       — model responded successfully
 *   "ratelimit"— HTTP 429; model works, just rate-limited
 *   "unknown"  — HTTP 401/403; probe can't auth (SDK may work differently) → treated as healthy
 *   "fail"     — HTTP 404/400 (model doesn't exist) or unrecoverable error → skip in routing
 *   "skipped"  — provider key not configured
 *   "pending"  — probe hasn't run yet → treated as healthy
 */
import type { ProviderConfig } from "../providers/shared/types.js";
import { logger } from "./logger.js";

export type HealthStatus = "pending" | "ok" | "fail" | "ratelimit" | "unknown" | "skipped";

export interface ModelHealthEntry {
  status: HealthStatus;
  latencyMs?: number;
  error?: string;
  testedAt?: string;
}

const HEALTH = new Map<string, ModelHealthEntry>();
const PROBE_TIMEOUT_MS = 14_000;
const STAGGER_MS = 400;

function hkey(providerId: string, modelId: string) {
  return `${providerId}\x00${modelId}`;
}

export function getModelHealth(providerId: string, modelId: string): ModelHealthEntry {
  return HEALTH.get(hkey(providerId, modelId)) ?? { status: "pending" };
}

/**
 * A model is healthy unless it is definitively broken (404 / bad model ID).
 * Auth issues (401), rate limits (429), and unprobed (pending) models are
 * all treated as healthy so valid API keys still route correctly.
 */
export function isModelHealthy(providerId: string, modelId: string): boolean {
  const h = HEALTH.get(hkey(providerId, modelId));
  if (!h) return true;
  return h.status !== "fail";
}

export function getHealthReport(): Record<string, Record<string, ModelHealthEntry>> {
  const out: Record<string, Record<string, ModelHealthEntry>> = {};
  for (const [k, v] of HEALTH) {
    const sep = k.indexOf("\x00");
    const pid = k.slice(0, sep);
    const mid = k.slice(sep + 1);
    (out[pid] ??= {})[mid] = v;
  }
  return out;
}

function set(pid: string, mid: string, entry: ModelHealthEntry) {
  HEALTH.set(hkey(pid, mid), entry);
}

function classify(status: number): HealthStatus {
  if (status === 200) return "ok";
  if (status === 429) return "ratelimit";
  if (status === 401 || status === 403) return "unknown"; // probe auth differs from SDK auth
  if (status === 404 || status === 400) return "fail";    // model doesn't exist / invalid ID
  return "fail";
}

// ─── Gemini probe via models metadata (GET, no generation cost) ───────────────

async function probeGemini(modelId: string): Promise<ModelHealthEntry> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return { status: "skipped", error: "GEMINI_API_KEY not set" };
  const start = Date.now();
  try {
    // GET /models/{model} is a zero-cost metadata check — validates key + model existence
    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${modelId}?key=${apiKey}`,
      { signal: AbortSignal.timeout(PROBE_TIMEOUT_MS) },
    );
    const latencyMs = Date.now() - start;
    const testedAt  = new Date().toISOString();
    const status    = classify(resp.status);
    if (status === "ok" || status === "ratelimit" || status === "unknown") {
      return { status, latencyMs, testedAt };
    }
    const body   = await resp.text().catch(() => "");
    let   detail = body.slice(0, 200);
    try { detail = JSON.parse(body)?.error?.message ?? detail; } catch { /**/ }
    return { status: "fail", error: `HTTP ${resp.status}: ${detail}`, testedAt };
  } catch (e: any) {
    return { status: "fail", error: e?.message ?? String(e), testedAt: new Date().toISOString() };
  }
}

// ─── OpenAI-compatible probe ──────────────────────────────────────────────────

async function probeOpenAI(
  modelId: string,
  baseUrl: string,
  apiKey: string,
  extraHeaders: Record<string, string> = {},
): Promise<ModelHealthEntry> {
  const start = Date.now();
  try {
    const resp = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        ...extraHeaders,
      },
      body: JSON.stringify({
        model: modelId,
        messages: [{ role: "user", content: "hi" }],
        max_tokens: 1,
        stream: false,
      }),
      signal: AbortSignal.timeout(PROBE_TIMEOUT_MS),
    });
    const latencyMs = Date.now() - start;
    const testedAt  = new Date().toISOString();
    const status    = classify(resp.status);
    if (status === "ok" || status === "ratelimit" || status === "unknown") {
      return { status, latencyMs, testedAt };
    }
    const body   = await resp.text().catch(() => "");
    let   detail = body.slice(0, 200);
    try { detail = JSON.parse(body)?.error?.message ?? detail; } catch { /**/ }
    return { status: "fail", error: `HTTP ${resp.status}: ${detail}`, testedAt };
  } catch (e: any) {
    return { status: "fail", error: e?.message ?? String(e), testedAt: new Date().toISOString() };
  }
}

// ─── Per-provider probe ───────────────────────────────────────────────────────

async function probeOneProvider(config: ProviderConfig): Promise<void> {
  const apiKey = process.env[config.envKey];
  const models = config.models ?? [{ id: config.defaultModel }];
  if (!apiKey) {
    for (const m of models) {
      set(config.id, m.id, { status: "skipped", error: `${config.envKey} not set` });
    }
    return;
  }

  for (let i = 0; i < models.length; i++) {
    const m = models[i];
    let result: ModelHealthEntry;
    try {
      if (config.id === "gemini") {
        result = await probeGemini(m.id);
      } else {
        const baseUrl = config.baseUrl ?? "";
        const extra: Record<string, string> = {};
        if (config.id === "openrouter") {
          extra["HTTP-Referer"] = process.env.APP_PUBLIC_URL ?? "http://localhost:8080";
          extra["X-Title"] = process.env.APP_NAME ?? "4trio";
        }
        result = await probeOpenAI(m.id, baseUrl, apiKey, extra);
      }
    } catch (e: any) {
      result = { status: "fail", error: e?.message ?? String(e), testedAt: new Date().toISOString() };
    }

    set(config.id, m.id, result);
    logger.info(
      { provider: config.id, model: m.id, status: result.status, latencyMs: result.latencyMs, err: result.error?.slice(0, 80) },
      "Model probe",
    );

    if (i < models.length - 1) {
      await new Promise(r => setTimeout(r, STAGGER_MS));
    }
  }
}

/**
 * Fire-and-forget: run probes for all providers in parallel (models within
 * each provider are staggered). Call after the server starts listening.
 */
export function scheduleStartupProbes(providers: ProviderConfig[]): void {
  Promise.all(providers.map(p => probeOneProvider(p)))
    .then(() => logger.info("All model probes complete"))
    .catch(e => logger.error({ err: String(e) }, "Model probe batch error"));
}
