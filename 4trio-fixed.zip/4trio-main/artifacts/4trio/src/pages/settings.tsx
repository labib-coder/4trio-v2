import { useState, useEffect } from "react";
import { usePageMeta } from "@/hooks/use-page-meta";
import { useLocation } from "wouter";
import {
  ArrowLeft, Moon, Sun, Sparkles, MessageSquare,
  Palette, Type, Trash2, AlertTriangle, Cpu,
  Shield, Lock, HardDrive, Zap, Volume2,
  Wand2, Brain, Globe, Unlock,
} from "lucide-react";
import { resetOnboarding } from "@/lib/onboarding";
import { MODEL_STORAGE_KEY, PROVIDER_INFO, PROVIDER_STORAGE_KEY, DEFAULT_PROVIDER, PROVIDER_ORDER, getModelHealthBadge, type ProviderId, type ModelHealthReport } from "@/lib/providers";
import {
  type Preferences, type ThemeId, type FontId, type TtsPrefs,
  THEMES, FONTS, loadPreferences, savePreferences, loadTtsPrefs, saveTtsPrefs,
} from "@/hooks/use-preferences";

const STORAGE_KEY = "4trio-conversations";

const PROVIDER_ICONS: Record<ProviderId, React.ElementType> = {
  auto:       Wand2,
  groq:       Zap,
  gemini:     Brain,
  cerebras:   Cpu,
  openrouter: Globe,
  uncensored: Unlock,
};

function Section({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-xl border border-border bg-card overflow-hidden ${className}`}>
      {children}
    </section>
  );
}
function SectionHeader({ icon: Icon, title }: { icon: React.ElementType; title: string }) {
  return (
    <div className="px-5 py-4 border-b border-border">
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Icon className="w-4 h-4 text-primary" />
        {title}
      </div>
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative w-11 h-6 rounded-full transition-colors ${checked ? "bg-primary" : "bg-muted border border-border"}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0"}`}
      />
    </button>
  );
}

export default function Settings() {
  usePageMeta({
    title: "Settings — 4trio AI Chat",
    description: "Customize your 4trio experience. Choose your AI provider, adjust themes, fonts, and manage your conversation history.",
    canonical: "https://4trio.up.railway.app/settings",
    ogImage: "https://4trio.up.railway.app/opengraph.jpg",
  });

  const [, setLocation] = useLocation();
  const [prefs, setPrefs] = useState<Preferences>(loadPreferences);
  const [darkMode, setDarkMode] = useState(true);
  const [confirmClear, setConfirmClear] = useState(false);
  const [introReset, setIntroReset] = useState(false);
  const [pendingFontSize, setPendingFontSize] = useState(Math.min(prefs.fontSize, 150));

  const [activeProvider, setActiveProvider] = useState<ProviderId>(() => {
    const v = localStorage.getItem(PROVIDER_STORAGE_KEY) as ProviderId | null;
    return v && PROVIDER_ORDER.includes(v) ? v : DEFAULT_PROVIDER;
  });
  const [activeModel, setActiveModel] = useState<string>(() => localStorage.getItem(MODEL_STORAGE_KEY) ?? "");
  const [modelHealth, setModelHealth] = useState<ModelHealthReport | null>(null);

  useEffect(() => {
    fetch("/api/status")
      .then(r => r.json())
      .then(d => setModelHealth(d?.modelHealth ?? null))
      .catch(() => {});
  }, []);

  // TTS preferences
  const [ttsPrefs, setTtsPrefs] = useState<TtsPrefs>(loadTtsPrefs);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    const loadVoices = () => setVoices(window.speechSynthesis.getVoices());
    loadVoices();
    window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", loadVoices);
  }, []);

  const updateTtsPref = <K extends keyof TtsPrefs>(key: K, value: TtsPrefs[K]) => {
    const next = { ...ttsPrefs, [key]: value };
    setTtsPrefs(next);
    saveTtsPrefs(next);
  };

  const selectProvider = (id: ProviderId) => {
    localStorage.setItem(PROVIDER_STORAGE_KEY, id);
    setActiveProvider(id);
    if (id !== "auto") {
      const models = PROVIDER_INFO[id].models ?? [];
      if (models.length > 0 && !models.some((model) => model.id === activeModel)) {
        localStorage.setItem(MODEL_STORAGE_KEY, PROVIDER_INFO[id].defaultModel ?? models[0].id);
        setActiveModel(PROVIDER_INFO[id].defaultModel ?? models[0].id);
      }
    }
  };

  const selectModel = (modelId: string) => {
    localStorage.setItem(MODEL_STORAGE_KEY, modelId);
    setActiveModel(modelId);
  };

  function updatePref<K extends keyof Preferences>(key: K, value: Preferences[K]) {
    const next = { ...prefs, [key]: value };
    setPrefs(next);
    savePreferences(next);
  }

  const toggleDark = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark", !darkMode);
  };

  const clearConversations = () => {
    localStorage.removeItem(STORAGE_KEY);
    setConfirmClear(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border sticky top-0 bg-background/90 backdrop-blur-sm z-10">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center gap-3 sm:gap-4">
          <button
            data-testid="back-from-settings"
            onClick={() => setLocation("/chat")}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to chat
          </button>
          <h1 className="text-base font-semibold">Settings</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 py-5 sm:py-8 space-y-4 sm:space-y-5">

        {/* Color Theme */}
        <Section>
          <SectionHeader icon={Palette} title="Color Theme" />
          <div className="p-5">
            <p className="text-xs text-muted-foreground mb-4">Choose an accent color for the entire app</p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {(Object.entries(THEMES) as [ThemeId, typeof THEMES[ThemeId]][]).map(([id, t]) => (
                <button
                  key={id}
                  data-testid={`theme-${id}`}
                  onClick={() => updatePref("theme", id)}
                  title={t.label}
                  className={`flex flex-col items-center gap-2 p-2.5 rounded-xl border transition-all ${
                    prefs.theme === id
                      ? "border-primary bg-primary/10 ring-1 ring-primary"
                      : "border-border hover:border-border/80 hover:bg-muted/40"
                  }`}
                >
                  <span className="w-8 h-8 rounded-full shadow-sm flex-shrink-0" style={{ backgroundColor: t.hex }} />
                  <span className={`text-xs font-medium leading-none ${prefs.theme === id ? "text-foreground" : "text-muted-foreground"}`}>
                    {t.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </Section>

        {/* Font Family */}
        <Section>
          <SectionHeader icon={Type} title="Font" />
          <div className="p-5 space-y-3">
            {(Object.entries(FONTS) as [FontId, typeof FONTS[FontId]][]).map(([id, f]) => (
              <button
                key={id}
                data-testid={`font-${id}`}
                onClick={() => updatePref("font", id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
                  prefs.font === id
                    ? "border-primary bg-primary/10 ring-1 ring-primary"
                    : "border-border hover:bg-muted/40"
                }`}
              >
                <div className="text-left">
                  <p className={`text-sm font-medium ${prefs.font === id ? "text-foreground" : "text-muted-foreground"}`}>{f.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: f.css }}>{f.sample}</p>
                </div>
                {prefs.font === id && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
              </button>
            ))}
          </div>
        </Section>

        {/* Text Size */}
        <Section>
          <SectionHeader icon={Type} title="Text Size" />
          <div className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Size</span>
              <span className="text-sm font-semibold tabular-nums text-primary">{pendingFontSize}%</span>
            </div>
            <div className="space-y-2">
              <input
                type="range" min={75} max={150} step={5}
                value={pendingFontSize}
                onChange={(e) => setPendingFontSize(Number(e.target.value))}
                className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary bg-muted"
                style={{ background: `linear-gradient(to right, hsl(var(--primary)) 0%, hsl(var(--primary)) ${((pendingFontSize - 75) / (150 - 75)) * 100}%, hsl(var(--muted)) ${((pendingFontSize - 75) / (150 - 75)) * 100}%, hsl(var(--muted)) 100%)` }}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>75%</span><span>100%</span><span>125%</span><span>150%</span>
              </div>
            </div>
            <div className="p-4 bg-muted/40 rounded-xl border border-border overflow-hidden">
              <p className="text-muted-foreground mb-1" style={{ fontSize: "11px" }}>Preview</p>
              <p className="font-medium leading-snug" style={{ fontSize: `${Math.round(pendingFontSize * 0.14)}px` }}>
                The quick brown fox jumps over the lazy dog.
              </p>
            </div>
            <div className="flex items-center justify-between">
              <button
                onClick={() => { setPendingFontSize(100); updatePref("fontSize", 100); }}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2"
              >
                Reset to default (100%)
              </button>
              <button
                onClick={() => updatePref("fontSize", pendingFontSize)}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:opacity-90 transition-opacity"
              >
                Apply changes
              </button>
            </div>
          </div>
        </Section>

        {/* Appearance */}
        <Section>
          <SectionHeader icon={Sun} title="Appearance" />
          <div className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Dark mode</p>
                <p className="text-xs text-muted-foreground mt-0.5">Toggle between dark and light themes</p>
              </div>
              <Toggle checked={darkMode} onChange={(v) => { setDarkMode(v); document.documentElement.classList.toggle("dark", v); }} />
            </div>
          </div>
        </Section>

        {/* AI Provider */}
        <Section>
          <SectionHeader icon={Cpu} title="AI Provider" />
          <div className="p-5 space-y-3">
            <p className="text-xs text-muted-foreground mb-1">
              Auto is the default — it picks the best provider for each message automatically. Choose manually to lock a specific provider.
            </p>
            {PROVIDER_ORDER.map((id) => {
              const info = PROVIDER_INFO[id];
              const active = activeProvider === id;
              const Icon = PROVIDER_ICONS[id];
              return (
                <button
                  key={id}
                  data-testid={`provider-${id}`}
                  onClick={() => selectProvider(id)}
                  className={`w-full text-left px-4 py-4 rounded-xl border transition-all ${
                    active ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-border hover:bg-muted/40"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${active ? "bg-primary/15" : "bg-muted"}`}>
                        <Icon className={`w-4 h-4 ${active ? "text-primary" : "text-muted-foreground"}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5 mb-1">
                          <span className={`text-sm font-semibold ${active ? "text-foreground" : "text-muted-foreground"}`}>{info.label}</span>
                          {info.badge && <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-mono">{info.badge}</span>}
                          {id === DEFAULT_PROVIDER && <span className="text-xs px-1.5 py-0.5 rounded bg-primary/15 text-primary font-medium">Default</span>}
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed">{info.desc}</p>
                      </div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 mt-1 flex items-center justify-center transition-colors ${active ? "border-primary bg-primary" : "border-border"}`}>
                      {active && <div className="w-1.5 h-1.5 rounded-full bg-primary-foreground" />}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </Section>



        {/* AI Model */}
        {activeProvider !== "auto" && (PROVIDER_INFO[activeProvider].models?.length ?? 0) > 0 && (
          <Section>
            <SectionHeader icon={Brain} title="AI Model" />
            <div className="p-5 space-y-3">
              <p className="text-xs text-muted-foreground mb-1">
                The selected model is sent with every chat request for this provider. Each provider validates only its own model list.
              </p>
              {PROVIDER_INFO[activeProvider].models!.map((model) => {
                const active = activeModel === model.id || (!activeModel && model.id === PROVIDER_INFO[activeProvider].defaultModel);
                return (
                  <button
                    key={model.id}
                    data-testid={`model-${model.id}`}
                    onClick={() => selectModel(model.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl border transition-all ${
                      active ? "border-primary bg-primary/10 ring-1 ring-primary" : "border-border hover:bg-muted/40"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5 mb-1">
                          <span className="text-sm font-semibold">{model.label}</span>
                          {model.id === PROVIDER_INFO[activeProvider].defaultModel && <span className="text-xs px-1.5 py-0.5 rounded bg-primary/15 text-primary font-medium">Default</span>}
                          {model.capabilities.vision && <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-mono">vision</span>}
                          {model.tags?.filter(t => t !== "text" && t !== "vision").map(t => (
                            <span key={t} className="text-xs px-1.5 py-0.5 rounded bg-muted/60 text-muted-foreground/70 font-mono">{t}</span>
                          ))}
                          {(() => {
                            const badge = getModelHealthBadge(modelHealth, activeProvider as Exclude<ProviderId, "auto">, model.id);
                            if (!badge) return null;
                            return <span className={`text-xs font-mono ${badge.color}`}>{badge.label}</span>;
                          })()}
                        </div>
                        <p className="text-xs text-muted-foreground font-mono break-all">{model.id}</p>
                      </div>
                      <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 mt-1 flex items-center justify-center transition-colors ${active ? "border-primary bg-primary" : "border-border"}`}>
                        {active && <div className="w-1.5 h-1.5 rounded-full bg-primary-foreground" />}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </Section>
        )}

        {/* Read Aloud / TTS */}
        <Section>
          <SectionHeader icon={Volume2} title="Read Aloud" />
          <div className="p-5 space-y-5">
            {/* Auto-read toggle */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Auto-read replies</p>
                <p className="text-xs text-muted-foreground mt-0.5">Automatically read assistant responses aloud after they finish</p>
              </div>
              <Toggle checked={ttsPrefs.autoRead} onChange={(v) => updateTtsPref("autoRead", v)} />
            </div>

            <div className="border-t border-border/50" />

            {/* Voice selection */}
            {voices.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">Browser voice</p>
                <select
                  value={ttsPrefs.voiceURI}
                  onChange={(e) => updateTtsPref("voiceURI", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-muted text-sm outline-none focus:ring-1 focus:ring-primary/30"
                >
                  <option value="">Default voice</option>
                  {voices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>
                  ))}
                </select>
              </div>
            )}

            {/* Rate */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium">Speed</p>
                <span className="text-xs tabular-nums text-primary font-semibold">{ttsPrefs.rate.toFixed(1)}×</span>
              </div>
              <input
                type="range" min={0.5} max={2} step={0.1}
                value={ttsPrefs.rate}
                onChange={(e) => updateTtsPref("rate", Number(e.target.value))}
                className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary"
                style={{ background: `linear-gradient(to right, hsl(var(--primary)) 0%, hsl(var(--primary)) ${((ttsPrefs.rate - 0.5) / 1.5) * 100}%, hsl(var(--muted)) ${((ttsPrefs.rate - 0.5) / 1.5) * 100}%, hsl(var(--muted)) 100%)` }}
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>0.5×</span><span>1×</span><span>2×</span>
              </div>
            </div>

            {/* Pitch */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium">Pitch</p>
                <span className="text-xs tabular-nums text-primary font-semibold">{ttsPrefs.pitch.toFixed(1)}</span>
              </div>
              <input
                type="range" min={0.5} max={2} step={0.1}
                value={ttsPrefs.pitch}
                onChange={(e) => updateTtsPref("pitch", Number(e.target.value))}
                className="w-full h-2 rounded-full appearance-none cursor-pointer accent-primary"
                style={{ background: `linear-gradient(to right, hsl(var(--primary)) 0%, hsl(var(--primary)) ${((ttsPrefs.pitch - 0.5) / 1.5) * 100}%, hsl(var(--muted)) ${((ttsPrefs.pitch - 0.5) / 1.5) * 100}%, hsl(var(--muted)) 100%)` }}
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Low</span><span>Normal</span><span>High</span>
              </div>
            </div>

            <div className="border-t border-border/50" />

            {/* Natural Voice */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Natural Voice</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Use the configured server-side natural voice for the Read button. Browser voice handles auto-read.
                </p>
              </div>
              <Toggle checked={ttsPrefs.useNaturalVoice} onChange={(v) => updateTtsPref("useNaturalVoice", v)} />
            </div>

            {ttsPrefs.useNaturalVoice && (
              <div className="rounded-lg border border-primary/20 bg-primary/5 px-4 py-3 text-xs text-muted-foreground">
                Natural Voice uses the server-side TTS provider configured by the deployment. It only triggers when you click Read — never on auto-read.
              </div>
            )}

            <button
              onClick={() => {
                const reset = { autoRead: false, voiceURI: "", rate: 1.0, pitch: 1.0, useNaturalVoice: false };
                setTtsPrefs(reset);
                saveTtsPrefs(reset);
              }}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2"
            >
              Reset voice settings
            </button>
          </div>
        </Section>

        {/* Conversations */}
        <Section>
          <SectionHeader icon={MessageSquare} title="Conversations" />
          <div className="p-5">
            {confirmClear ? (
              <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-destructive">Delete all conversations?</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      This permanently removes all chat history from your browser. This cannot be undone.
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    data-testid="confirm-clear"
                    onClick={clearConversations}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-medium hover:opacity-90 transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Yes, delete all
                  </button>
                  <button
                    onClick={() => setConfirmClear(false)}
                    className="px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:bg-muted transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Clear all conversations</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Remove all chat history stored in your browser</p>
                </div>
                <button
                  data-testid="clear-conversations-btn"
                  onClick={() => setConfirmClear(true)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-destructive/40 text-destructive text-sm font-medium hover:bg-destructive/10 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear all
                </button>
              </div>
            )}
          </div>
        </Section>

        {/* Onboarding */}
        <Section>
          <SectionHeader icon={Sparkles} title="Testing" />
          <div className="p-5 flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium">Reset introduction</p>
              <p className="text-xs text-muted-foreground mt-0.5">Remove the local onboarding flag so this browser sees the intro again.</p>
            </div>
            <button
              data-testid="reset-introduction-btn"
              onClick={() => {
                resetOnboarding();
                setIntroReset(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              {introReset ? "Reset done" : "Reset"}
            </button>
          </div>
        </Section>

        {/* About */}
        <Section>
          <div className="relative overflow-hidden p-5 border-b border-border" style={{ background: "linear-gradient(135deg, hsl(var(--primary)/0.12), hsl(var(--primary)/0.04))" }}>
            <div className="pointer-events-none absolute -top-8 -right-8 w-40 h-40 rounded-full" style={{ background: "radial-gradient(circle, hsl(var(--primary)/0.18), transparent 70%)", filter: "blur(24px)" }} />
            <div className="relative flex items-center gap-3 mb-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.7))", boxShadow: "0 4px 20px hsl(var(--primary)/0.35)" }}>
                <Sparkles className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
              </div>
              <div>
                <p className="text-lg font-bold tracking-tight">4trio</p>
                <p className="text-xs text-muted-foreground">AI chat that actually thinks fast</p>
              </div>
            </div>
            <p className="relative text-xs text-muted-foreground leading-relaxed mb-3">
              Built for people who want real AI without the hassle — no accounts, no data collection, no subscriptions. Just open it and chat.
            </p>
            <div className="relative flex flex-wrap gap-1.5">
              {["Universal providers", "React + Vite", "Open models", "Private by design"].map(tag => (
                <span key={tag} className="text-xs px-2.5 py-1 rounded-full border text-primary font-medium" style={{ borderColor: "hsl(var(--primary)/0.3)", background: "hsl(var(--primary)/0.08)" }}>
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="p-4 sm:p-5 space-y-3">
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              {[
                { icon: Shield,    label: "Privacy",  value: "No tracking" },
                { icon: Zap,       label: "Speed",    value: "Ultra-fast AI" },
                { icon: Lock,      label: "Account",  value: "Not required" },
                { icon: HardDrive, label: "Storage",  value: "Your device" },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="bg-muted/40 rounded-xl p-3 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] text-muted-foreground leading-none mb-0.5">{label}</p>
                    <p className="text-xs font-semibold truncate">{value}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl border" style={{ borderColor: "hsl(var(--primary)/0.25)", background: "hsl(var(--primary)/0.06)" }}>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.7))" }}>
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold">4trio</p>
                <p className="text-xs text-muted-foreground">Provider-agnostic · Host anywhere</p>
              </div>
              <Sparkles className="w-4 h-4 text-muted-foreground/70 ml-auto flex-shrink-0" />
            </div>

            <p className="text-[10px] text-muted-foreground/70 text-center pt-1">4trio v1.0 · Your conversations never leave this device</p>
          </div>
        </Section>

        <div className="pb-4">
          <button
            data-testid="open-chat-from-settings"
            onClick={() => setLocation("/chat")}
            className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <MessageSquare className="w-4 h-4" />
            Back to chat
          </button>
        </div>
      </main>
    </div>
  );
}
