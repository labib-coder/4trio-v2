import { useState, useRef, useEffect, useCallback, useMemo, memo, lazy, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import {
  Plus, Trash2, Send, Sparkles, Menu, X,
  MessageSquare, RotateCcw, Settings, Search, Pencil, Paperclip,
  Copy, Check, Mic, MicOff, Volume2, VolumeX, Loader2, Pause, Play,
  ChevronDown, FileText, ChevronUp, Download,
} from "lucide-react";
import { loadTtsPrefs, type TtsPrefs } from "@/hooks/use-preferences";
import { usePageMeta } from "@/hooks/use-page-meta";
import { getActiveProvider, getActiveModel, getActiveProviderInfo, getProviderCapabilities, PROVIDER_INFO, type ProviderId, type ProviderStatusMap } from "@/lib/providers";
import { getRandomSuggestedPrompts } from "@/lib/suggested-prompts";

const ChatMarkdown = lazy(() => import("@/components/chat-markdown"));

const MAX_IMAGE_EDGE = 1280;
const IMAGE_JPEG_QUALITY = 0.72;
const TEXT_ATTACHMENT_THRESHOLD = 500;


// ─── TTS text cleaner ──────────────────────────────────────────────────────
function cleanForTts(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, ". Code block. ")
    .replace(/`[^`\n]+`/g, "")
    .replace(/#{1,6}\s*/g, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*\n]+)\*/g, "$1")
    .replace(/__([^_]+)__/g, "$1")
    .replace(/_([^_\n]+)_/g, "$1")
    .replace(/~~([^~]+)~~/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/https?:\/\/\S+/g, "")
    .replace(/<[^>]+>/g, "")
    .replace(/[#*`>~|\\[\]{}]/g, "")
    .replace(/\n{3,}/g, ". ")
    .replace(/\n/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

// ─── Greeting ──────────────────────────────────────────────────────────────
function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

// ─── Interfaces ────────────────────────────────────────────────────────────
interface AttachedImage { dataUrl: string; mimeType: string; }
interface GeneratedImage { dataUrl: string; mimeType: string; }

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  imageDataUrls?: string[];
  generatedImages?: GeneratedImage[];
}

interface StreamingMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
  imageDataUrls?: string[];
  generatedImages?: GeneratedImage[];
  truncated?: boolean;
  resolvedModel?: string;
  resolvedProvider?: string;
}

interface StoredConversation {
  id: string;
  title: string;
  titleGenerated?: boolean;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

// ─── Storage ───────────────────────────────────────────────────────────────
const STORAGE_KEY = "4trio-conversations";

function loadConversations(): StoredConversation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredConversation[]) : [];
  } catch { return []; }
}

function saveConversations(convs: StoredConversation[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(convs));
  } catch (error) {
    console.warn("Unable to save conversations", error);
  }
}

function genId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}


function isHeicImage(file: File): boolean {
  const type = file.type.toLowerCase();
  const name = file.name.toLowerCase();
  return type === "image/heic" || type === "image/heif" || name.endsWith(".heic") || name.endsWith(".heif");
}

function isImageFile(file: File): boolean {
  const type = file.type.toLowerCase();
  const name = file.name.toLowerCase();
  return type.startsWith("image/") || /\.(jpe?g|png|gif|webp)$/i.test(name);
}

function readBlobAsDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read the selected image."));
    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Could not preview the selected image."));
    };
    reader.readAsDataURL(blob);
  });
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("This image format is not supported. Please upload a JPG or PNG."));
    image.src = url;
  });
}

function canvasToDataUrl(canvas: HTMLCanvasElement, type: string, quality?: number): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!canvas.toBlob) {
      try {
        resolve(canvas.toDataURL(type, quality));
      } catch {
        reject(new Error("Could not process the selected image."));
      }
      return;
    }

    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Could not process the selected image."));
        return;
      }
      readBlobAsDataUrl(blob).then(resolve).catch(reject);
    }, type, quality);
  });
}

async function getDrawableImage(file: File): Promise<{ source: CanvasImageSource; width: number; height: number; cleanup: () => void }> {
  if ("createImageBitmap" in window) {
    try {
      const bitmap = await createImageBitmap(file);
      return {
        source: bitmap,
        width: bitmap.width,
        height: bitmap.height,
        cleanup: () => bitmap.close(),
      };
    } catch {
      // Fall through to the object URL path for older/mobile browser quirks.
    }
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(objectUrl);
    return {
      source: image,
      width: image.naturalWidth || image.width,
      height: image.naturalHeight || image.height,
      cleanup: () => URL.revokeObjectURL(objectUrl),
    };
  } catch (error) {
    URL.revokeObjectURL(objectUrl);
    throw error;
  }
}

async function compressImageForChat(file: File): Promise<AttachedImage> {
  if (isHeicImage(file)) {
    throw new Error("HEIC/HEIF photos are not supported yet. Please upload or share the photo as JPG or PNG.");
  }

  if (!isImageFile(file)) {
    throw new Error("Please choose an image file.");
  }

  const drawable = await getDrawableImage(file);
  try {
    if (!drawable.width || !drawable.height) {
      throw new Error("Could not read the selected image dimensions.");
    }

    const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(drawable.width, drawable.height));
    const targetWidth = Math.max(1, Math.round(drawable.width * scale));
    const targetHeight = Math.max(1, Math.round(drawable.height * scale));
    const outputType = file.type.toLowerCase() === "image/png" && scale === 1 ? "image/png" : "image/jpeg";

    const canvas = document.createElement("canvas");
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext("2d", { alpha: outputType === "image/png" });
    if (!ctx) throw new Error("Could not prepare the image preview.");

    ctx.drawImage(drawable.source, 0, 0, targetWidth, targetHeight);
    const dataUrl = await canvasToDataUrl(canvas, outputType, outputType === "image/jpeg" ? IMAGE_JPEG_QUALITY : undefined);
    return { dataUrl, mimeType: outputType };
  } finally {
    drawable.cleanup();
  }
}

// ─── Conversation title helper ────────────────────────────────────────────
function isVagueFirstMessage(text: string): boolean {
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
  return /^(what|huh|hm|hmm|uh|umm|confused|im confused|i am confused|what do you mean|i dont understand)$/i.test(normalized);
}

function generateLocalTitle(messages: { role: string; content: string }[]): string {
  const first = messages.find(m => m.role === "user")?.content.trim() ?? "";
  if (isVagueFirstMessage(first)) return "User is confused";

  const stripped = first
    .replace(/^(please\s+)?(what|how|why|when|where|who|can you|could you|would you|help me|explain|write|create|make|give me|show me|tell me)\s+/i, "")
    .trim();
  const words = stripped.split(/\s+/).filter(Boolean).slice(0, 6);
  const title = words.join(" ");
  return title ? title.charAt(0).toUpperCase() + title.slice(1) : first.slice(0, 40) || "New chat";
}

// ─── TypingDots ────────────────────────────────────────────────────────────
function TypingDots() {
  return (
    <span className="inline-flex items-center gap-[5px] px-1 py-0.5">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="inline-block w-[7px] h-[7px] rounded-full"
          style={{ background: "hsl(var(--primary)/0.7)" }}
          animate={{ opacity: [0.35, 1, 0.35], scale: [0.8, 1.15, 0.8], y: [0, -4, 0] }}
          transition={{ duration: 0.75, repeat: Infinity, delay: i * 0.16, ease: "easeInOut" }}
        />
      ))}
    </span>
  );
}

// ─── MessageBubble ─────────────────────────────────────────────────────────
const MessageBubble = memo(function MessageBubble({
  msg,
  onContinue,
  isStreamingAnything,
}: {
  msg: StreamingMessage;
  onContinue?: () => void;
  isStreamingAnything: boolean;
}) {
  const isUser = msg.role === "user";
  const isTyping = msg.streaming && msg.content === "";
  const userHasImages = isUser && Boolean(msg.imageDataUrls?.length);
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isTtsLoading, setIsTtsLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isLongUserMsg = isUser && msg.content.length > TEXT_ATTACHMENT_THRESHOLD && !(msg.imageDataUrls?.length);
  const usingBrowserTts = useRef(false);
  const groqAudioCache = useRef<string | null>(null); // cached object URL

  // Stop TTS when chat switches or user sends a new message
  useEffect(() => {
    const handler = () => {
      audioRef.current?.pause();
      if (audioRef.current) { audioRef.current.src = ""; audioRef.current = null; }
      if (usingBrowserTts.current) window.speechSynthesis.cancel();
      usingBrowserTts.current = false;
      setIsSpeaking(false);
      setIsPaused(false);
    };
    window.addEventListener("tts:stop", handler);
    return () => window.removeEventListener("tts:stop", handler);
  }, []);

  // Auto-read: listen for the trigger dispatched by parent after streaming
  useEffect(() => {
    const handler = (e: Event) => {
      const ce = e as CustomEvent<{ id: string; text?: string }>;
      const text = ce.detail.text ?? msg.content;
      if (ce.detail.id === msg.id && !isUser && text && !isSpeaking) {
        triggerBrowserTts(text);
      }
    };
    window.addEventListener("tts:auto-read", handler as EventListener);
    return () => window.removeEventListener("tts:auto-read", handler as EventListener);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [msg.id, msg.content, isUser, isSpeaking]);

  const triggerBrowserTts = useCallback((text: string) => {
    const prefs = loadTtsPrefs();
    const cleaned = cleanForTts(text).slice(0, 3000);
    if (!cleaned) return;

    window.speechSynthesis.cancel();
    usingBrowserTts.current = true;

    const utterance = new SpeechSynthesisUtterance(cleaned);
    utterance.rate = prefs.rate;
    utterance.pitch = prefs.pitch;

    if (prefs.voiceURI) {
      const voices = window.speechSynthesis.getVoices();
      const found = voices.find(v => v.voiceURI === prefs.voiceURI);
      if (found) utterance.voice = found;
    }

    window.speechSynthesis.speak(utterance);
    const keepAlive = window.setInterval(() => {
      if (!window.speechSynthesis.speaking) { window.clearInterval(keepAlive); return; }
      window.speechSynthesis.resume();
    }, 10_000);
    utterance.onend = () => { window.clearInterval(keepAlive); setIsSpeaking(false); setIsPaused(false); usingBrowserTts.current = false; };
    utterance.onerror = () => { window.clearInterval(keepAlive); setIsSpeaking(false); setIsPaused(false); usingBrowserTts.current = false; };
    setIsSpeaking(true);
  }, []);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(msg.content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [msg.content]);

  const handleStopTts = useCallback(() => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.src = ""; audioRef.current = null; }
    if (groqAudioCache.current) { URL.revokeObjectURL(groqAudioCache.current); groqAudioCache.current = null; }
    if (usingBrowserTts.current) window.speechSynthesis.cancel();
    usingBrowserTts.current = false;
    setIsSpeaking(false);
    setIsPaused(false);
  }, []);

  const handleTogglePause = useCallback(() => {
    if (isPaused) {
      audioRef.current?.play().catch(() => {});
      if (usingBrowserTts.current) window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      audioRef.current?.pause();
      if (usingBrowserTts.current) window.speechSynthesis.pause();
      setIsPaused(true);
    }
  }, [isPaused]);

  const handleSpeak = useCallback(async () => {
    if (isSpeaking) { handleTogglePause(); return; }

    // Stop any other ongoing TTS first
    window.dispatchEvent(new CustomEvent("tts:stop"));

    const prefs: TtsPrefs = loadTtsPrefs();
    const text = cleanForTts(msg.content).slice(0, 3000);
    if (!text) return;

    setIsTtsLoading(true);
    setIsPaused(false);

    if (prefs.useNaturalVoice) {
      // Try server-side natural voice — fall back to browser on failure
      try {
        // Use cached audio if available
        if (groqAudioCache.current) {
          const audio = new Audio(groqAudioCache.current);
          audioRef.current = audio;
          audio.onended = () => { setIsSpeaking(false); setIsPaused(false); };
          audio.onerror = () => { setIsSpeaking(false); setIsPaused(false); };
          await audio.play();
          setIsSpeaking(true);
          setIsTtsLoading(false);
          return;
        }

        const r = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });

        if (!r.ok) throw new Error(`TTS ${r.status}`);
        const blob = await r.blob();
        if (blob.size < 100) throw new Error("Empty audio");

        const url = URL.createObjectURL(blob);
        groqAudioCache.current = url;

        const audio = new Audio(url);
        audioRef.current = audio;
        audio.onended = () => { setIsSpeaking(false); setIsPaused(false); };
        audio.onerror = () => { setIsSpeaking(false); setIsPaused(false); URL.revokeObjectURL(url); groqAudioCache.current = null; };
        await audio.play();
        setIsSpeaking(true);
      } catch {
        // Fall back to browser TTS
        triggerBrowserTts(msg.content);
      }
    } else {
      // Browser TTS (default)
      triggerBrowserTts(msg.content);
    }

    setIsTtsLoading(false);
  }, [isSpeaking, handleTogglePause, msg.content, triggerBrowserTts]);

  const showContinue = msg.truncated && !msg.streaming && !isUser && !isStreamingAnything;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 420, damping: 34, mass: 0.8 }}
      className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"} group/bubble`}
      style={{ willChange: "transform, opacity" }}
    >
      {!isUser && (
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-1"
          style={{ background: "hsl(var(--primary)/0.1)", border: "1px solid hsl(var(--primary)/0.25)" }}
        >
          <Sparkles className="w-3.5 h-3.5 text-primary" />
        </div>
      )}
      <div className={`relative min-w-0 ${isUser ? "max-w-[88%] sm:max-w-[75%]" : "w-full"}`}>
        <div
          className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
            isUser
              ? userHasImages ? "bg-card border border-border text-foreground rounded-tr-sm" : "text-white rounded-tr-sm"
              : "bg-card border border-border text-foreground rounded-tl-sm overflow-hidden"
          }`}
          style={isUser && !userHasImages ? {
            background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.8))",
            boxShadow: "0 2px 12px hsl(var(--primary)/0.3)",
            wordBreak: "break-word", overflowWrap: "anywhere",
          } : { wordBreak: "break-word", overflowWrap: "anywhere" }}
          data-testid={`message-${msg.role}`}
        >
          {isUser && msg.imageDataUrls && msg.imageDataUrls.length > 0 && (
            <div className={`mb-2 rounded-2xl bg-background/70 border border-border/70 p-2 ${msg.imageDataUrls.length > 1 ? "grid grid-cols-2 gap-2" : ""}`}>
              {msg.imageDataUrls.map((url, i) => (
                <img key={i} src={url} alt={`Attached image ${i + 1}`} className="max-w-full max-h-64 rounded-xl object-contain block bg-muted/30" />
              ))}
            </div>
          )}
          {isTyping ? (
            <TypingDots />
          ) : isUser ? (
            isLongUserMsg ? (
              <div>
                <div className="flex items-center gap-1.5 mb-2 opacity-70">
                  <FileText className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="text-xs font-medium">{msg.content.split("\n").length} lines · {msg.content.length} chars</span>
                </div>
                <span style={{ whiteSpace: "pre-wrap" }}>
                  {expanded ? msg.content : msg.content.slice(0, 200) + (msg.content.length > 200 ? "…" : "")}
                </span>
                <button
                  onClick={() => setExpanded((p) => !p)}
                  className="mt-1.5 flex items-center gap-1 text-xs opacity-70 hover:opacity-100 transition-opacity"
                >
                  {expanded ? <><ChevronUp className="w-3 h-3" />Show less</> : <><ChevronDown className="w-3 h-3" />Show full text</>}
                </button>
              </div>
            ) : (
              msg.content ? <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span> : null
            )
          ) : (
            <div className="chat-message-content min-w-0 max-w-full overflow-hidden break-words">
              <Suspense fallback={<span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span>}>
                <ChatMarkdown content={msg.content} />
              </Suspense>
              {msg.generatedImages && msg.generatedImages.length > 0 && (
                <div className="mt-3 grid gap-3">
                  {msg.generatedImages.map((image, i) => {
                    const ext = image.mimeType.split("/")[1]?.split(";")[0] || "png";
                    return (
                      <figure key={`${image.dataUrl.slice(0, 32)}-${i}`} className="rounded-xl border border-border bg-background/60 p-2">
                        <img src={image.dataUrl} alt={`Generated image ${i + 1}`} className="max-h-[420px] w-full rounded-lg object-contain bg-muted/30" />
                        <figcaption className="mt-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                          <span>Generated image {i + 1}</span>
                          <a
                            href={image.dataUrl}
                            download={`4trio-generated-${i + 1}.${ext}`}
                            className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 hover:bg-muted hover:text-foreground transition-colors"
                          >
                            <Download className="w-3 h-3" />
                            Download
                          </a>
                        </figcaption>
                      </figure>
                    );
                  })}
                </div>
              )}
              {msg.streaming && (
                <span className="inline-block w-2 h-3.5 bg-current ml-0.5 animate-pulse rounded-sm opacity-60 align-middle" />
              )}
            </div>
          )}
        </div>

        {/* Continue button */}
        {showContinue && onContinue && (
          <div className="mt-2 flex">
            <button
              onClick={onContinue}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary/30 bg-primary/5 text-xs text-primary font-medium hover:bg-primary/10 transition-colors"
            >
              <ChevronDown className="w-3 h-3" />
              Continue generating
            </button>
          </div>
        )}

        {/* Action buttons */}
        {!isUser && !isTyping && msg.content && (
          <div className="mt-1.5 flex items-center gap-0.5 sm:absolute sm:-bottom-7 sm:left-0 sm:mt-0 sm:opacity-0 sm:group-hover/bubble:opacity-100 sm:transition-all">
            <button
              onClick={handleCopy}
              title={copied ? "Copied!" : "Copy response"}
              className="flex items-center gap-1 px-2 py-1 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              {copied ? (
                <><Check className="w-3 h-3 text-primary" /><span className="text-primary">Copied</span></>
              ) : (
                <><Copy className="w-3 h-3" /><span>Copy</span></>
              )}
            </button>

            {isSpeaking ? (
              <>
                <button
                  onClick={handleTogglePause}
                  title={isPaused ? "Resume" : "Pause"}
                  className="flex items-center gap-1 px-2 py-1 rounded-md text-xs hover:bg-muted transition-colors text-primary"
                >
                  {isPaused ? <><Play className="w-3 h-3" /><span>Resume</span></> : <><Pause className="w-3 h-3" /><span>Pause</span></>}
                </button>
                <button
                  onClick={handleStopTts}
                  title="Stop reading"
                  className="flex items-center gap-1 px-2 py-1 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                >
                  <VolumeX className="w-3 h-3" /><span>Stop</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleSpeak}
                title="Read aloud"
                disabled={isTtsLoading || Boolean(msg.streaming)}
                className="flex items-center gap-1 px-2 py-1 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors disabled:opacity-50"
              >
                {isTtsLoading ? (
                  <><Loader2 className="w-3 h-3 animate-spin" /><span>Loading…</span></>
                ) : (
                  <><Volume2 className="w-3 h-3" /><span>Read</span></>
                )}
              </button>
            )}

            {msg.resolvedProvider && (
              <span className="ml-1 flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-muted border border-border/50 text-[10px] text-muted-foreground font-medium hidden sm:flex select-none">
                {PROVIDER_INFO[msg.resolvedProvider as ProviderId]?.label ?? msg.resolvedProvider}
                {msg.resolvedModel && (
                  <span className="opacity-40 font-mono">
                    · {msg.resolvedModel.split("/").pop()?.split("-").slice(0, 2).join("-")}
                  </span>
                )}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
});

// ─── Status dot ────────────────────────────────────────────────────────────
type StatusState = { phase: "loading" | "no-internet" | "offline" | "online"; providers: ProviderStatusMap | null };

const PROVIDER_LABELS: Record<Exclude<ProviderId, "auto">, string> = {
  groq: "Groq", gemini: "Gemini", cerebras: "Cerebras", openrouter: "OpenRouter", uncensored: "Featherless.ai",
};

const StatusDot = memo(function StatusDot({ isStreaming }: { isStreaming: boolean }) {
  const [state, setState] = useState<StatusState>({ phase: "loading", providers: null });
  const [hovering, setHovering] = useState(false);

  useEffect(() => {
    const check = async () => {
      if (!navigator.onLine) { setState(s => ({ ...s, phase: "no-internet" })); return; }
      try {
        const res = await fetch("/api/status");
        if (res.ok) {
          const data = await res.json();
          setState({ phase: data.online ? "online" : "offline", providers: data.providers ?? null });
        } else {
          setState(s => ({ ...s, phase: "offline" }));
        }
      } catch { setState(s => ({ ...s, phase: "offline" })); }
    };
    check();
    const iv = setInterval(check, 30_000);
    window.addEventListener("online",  check);
    window.addEventListener("offline", check);
    return () => { clearInterval(iv); window.removeEventListener("online", check); window.removeEventListener("offline", check); };
  }, []);

  const { phase, providers } = state;
  const dotColor = phase === "loading" ? "bg-yellow-400" : phase === "online" ? "bg-green-400" : "bg-red-400";
  const label    = phase === "loading" ? "Connecting…" : phase === "online" ? "Online" : phase === "no-internet" ? "No internet" : "Offline";
  const hasProviders = providers && Object.values(providers).some((entry) => entry?.configured);

  return (
    <div
      className="relative flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-muted border border-border text-xs font-medium select-none cursor-default"
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
    >
      {/* Dot / streaming wave */}
      {isStreaming ? (
        <span className="inline-flex items-end gap-[3px] h-3">
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              className="block w-[5px] rounded-full"
              style={{ background: "hsl(var(--primary))" }}
              animate={{ height: ["3px", "10px", "3px"], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }}
            />
          ))}
        </span>
      ) : (
        <span
          className={`w-2 h-2 rounded-full flex-shrink-0 ${dotColor}`}
          style={phase !== "offline" && phase !== "no-internet" ? { boxShadow: `0 0 6px currentColor` } : undefined}
        />
      )}

      <span className="text-muted-foreground">{isStreaming ? "Generating…" : label}</span>

      {/* Provider tooltip */}
      {hovering && hasProviders && !isStreaming && (
        <div
          className="absolute right-0 top-full mt-2 z-50 rounded-xl border border-border bg-popover shadow-xl p-3 min-w-[160px]"
          style={{ boxShadow: "0 8px 32px rgba(0,0,0,0.18)" }}
        >
          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Providers</p>
          <div className="space-y-1.5">
            {(Object.keys(PROVIDER_LABELS) as Exclude<ProviderId, "auto">[]).map((key) => {
              const active = providers?.[key]?.configured ?? false;
              return (
                <div key={key} className="flex items-center gap-2 text-xs">
                  <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${active ? "bg-green-400" : "bg-muted-foreground/30"}`} />
                  <span className={active ? "text-foreground" : "text-muted-foreground/70"}>{PROVIDER_LABELS[key]}</span>
                  {active && <span className="ml-auto text-[10px] text-green-500 font-medium">active</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
});

// ─── Main Chat component ───────────────────────────────────────────────────
export default function Chat() {
  usePageMeta({
    title: "4trio — AI Chat | Talk to Llama 4, Gemini & More",
    description: "Start a free AI conversation on 4trio. Chat with Llama 4 Scout, Gemini Flash, and more — powered by Groq for instant responses. No sign-up needed.",
    canonical: "https://4trio.up.railway.app/chat",
    ogImage: "https://4trio.up.railway.app/opengraph.jpg",
  });

  const [, setLocation] = useLocation();
  const [conversations, setConversations] = useState<StoredConversation[]>(() =>
    loadConversations().sort((a, b) => b.updatedAt - a.updatedAt)
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [streamingMessages, setStreamingMessages] = useState<StreamingMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [hoveredConvId, setHoveredConvId] = useState<string | null>(null);
  const [renamingConvId, setRenamingConvId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestedPrompts, setSuggestedPrompts] = useState(() => getRandomSuggestedPrompts());
  const [attachedImages, setAttachedImages] = useState<AttachedImage[]>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isProcessingImages, setIsProcessingImages] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [textAttachment, setTextAttachment] = useState<{ content: string; lineCount: number; charCount: number; preview: string } | null>(null);
  const [providerStatus, setProviderStatus] = useState<ProviderStatusMap | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const focusChatInput = useCallback(() => {
    requestAnimationFrame(() => textareaRef.current?.focus({ preventScroll: true }));
  }, []);

  const selectedConv = useMemo(() => conversations.find((c) => c.id === selectedId) ?? null, [conversations, selectedId]);
  const activeProvider = getActiveProvider();
  const activeCapabilities = getProviderCapabilities(activeProvider, providerStatus);
  const maxImages = activeCapabilities.maxImages;
  const canUploadImages = activeCapabilities.vision && maxImages > 0;

  useEffect(() => {
    let cancelled = false;
    fetch("/api/status")
      .then((res) => res.ok ? res.json() : null)
      .then((data) => { if (!cancelled) setProviderStatus(data?.providers ?? null); })
      .catch(() => { if (!cancelled) setProviderStatus(null); });
    return () => { cancelled = true; };
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") { e.preventDefault(); setSearchOpen((p) => !p); setSearchQuery(""); }
      if ((e.ctrlKey || e.metaKey) && e.key === "n") { e.preventDefault(); handleNewChat(); }
      if (e.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (searchOpen) setTimeout(() => searchInputRef.current?.focus(), 50);
  }, [searchOpen]);

  const filteredConversations = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return conversations;
    return conversations.filter((c) =>
      c.title.toLowerCase().includes(query) ||
      c.messages.some((m) => m.content.toLowerCase().includes(query))
    );
  }, [conversations, searchQuery]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [streamingMessages]);

  const resizeTextarea = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, []);

  useEffect(() => { resizeTextarea(); }, [inputValue, resizeTextarea]);

  useEffect(() => {
    if (!isStreaming && !isRecording && !isTranscribing && !searchOpen && !renamingConvId) {
      focusChatInput();
    }
  }, [focusChatInput, isRecording, isStreaming, isTranscribing, renamingConvId, searchOpen, selectedId]);

  const selectConversation = (id: string) => {
    const conv = conversations.find((c) => c.id === id);
    if (!conv) return;
    window.dispatchEvent(new CustomEvent("tts:stop"));
    setSelectedId(id);
    setStreamingMessages(
      conv.messages.map((m, i) => ({
        id: `${id}-${i}`,
        role: m.role,
        content: m.content,
        imageDataUrls: m.imageDataUrls,
        generatedImages: m.generatedImages,
      }))
    );
    setSidebarOpen(false);
    focusChatInput();
  };

  const handleMicClick = async () => {
    if (isTranscribing) return;
    if (isRecording) { mediaRecorderRef.current?.stop(); return; }

    window.dispatchEvent(new CustomEvent("tts:stop"));

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/ogg";
      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        setIsRecording(false);
        setIsTranscribing(true);
        try {
          const blob = new Blob(audioChunksRef.current, { type: mimeType });
          const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve((reader.result as string).split(",")[1]);
            reader.readAsDataURL(blob);
          });
          const res = await fetch("/api/transcribe", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ audio: base64, mimeType }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.text?.trim()) {
              setInputValue((prev) => (prev ? prev + " " + data.text : data.text));
              focusChatInput();
            }
          }
        } catch { /* silent */ }
        setIsTranscribing(false);
      };

      recorder.start();
      setIsRecording(true);
    } catch {
      setIsRecording(false);
    }
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (!files.length) return;

    setUploadError(null);
    if (!canUploadImages) {
      setUploadError(`${getActiveProviderInfo().label} does not support image uploads. Choose Auto, Gemini, or another vision-capable provider.`);
      return;
    }

    const remaining = maxImages - attachedImages.length;
    const selected = files.slice(0, remaining);
    if (selected.length === 0) {
      setUploadError(`You can attach up to ${maxImages} image${maxImages === 1 ? "" : "s"} with this model.`);
      return;
    }

    setIsProcessingImages(true);
    try {
      const processed: AttachedImage[] = [];
      for (const file of selected) {
        processed.push(await compressImageForChat(file));
      }

      setAttachedImages((prev) => [...prev, ...processed].slice(0, maxImages));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Image upload failed. Please try a smaller JPG or PNG.";
      setUploadError(message);
    } finally {
      setIsProcessingImages(false);
      focusChatInput();
    }
  };

  const selectedProviderInfo = PROVIDER_INFO[activeProvider];

  const convertToTextAttachment = useCallback((text: string) => {
    const lines = text.split("\n");
    setTextAttachment({
      content: text,
      lineCount: lines.length,
      charCount: text.length,
      preview: text.slice(0, 80).replace(/\n/g, " ") + (text.length > 80 ? "…" : ""),
    });
    setInputValue("");
  }, []);

  const handleNewChat = () => {
    window.dispatchEvent(new CustomEvent("tts:stop"));
    setSelectedId(null);
    setStreamingMessages([]);
    setInputValue("");
    setAttachedImages([]);
    setUploadError(null);
    setTextAttachment(null);
    setSidebarOpen(false);
    setSuggestedPrompts(getRandomSuggestedPrompts());
    focusChatInput();
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = conversations.filter((c) => c.id !== id);
    setConversations(updated);
    saveConversations(updated);
    if (selectedId === id) { setSelectedId(null); setStreamingMessages([]); }
  };

  const startRename = (e: React.MouseEvent, id: string, currentTitle: string) => {
    e.stopPropagation();
    setRenamingConvId(id);
    setRenameValue(currentTitle);
  };

  const commitRename = (id: string) => {
    const trimmed = renameValue.trim();
    if (trimmed) {
      const updated = conversations.map((c) => c.id === id ? { ...c, title: trimmed } : c);
      setConversations(updated);
      saveConversations(updated);
    }
    setRenamingConvId(null);
  };

  // ─── Title generation via API ─────────────────────────────────────────
  const generateTitle = useCallback(async (convId: string, userMessage: string) => {
    try {
      const res = await fetch("/api/chat/title", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      });
      if (!res.ok) return;
      const { title } = await res.json();
      if (!title || typeof title !== "string") return;
      setConversations((prev) => {
        const updated = prev.map((c) => c.id === convId ? { ...c, title: title.trim(), titleGenerated: true } : c);
        saveConversations(updated);
        return updated;
      });
    } catch { /* silent — local title already set */ }
  }, []);

  // ─── Stream helper ─────────────────────────────────────────────────────
  async function streamResponse(
    body: Record<string, unknown>,
    signal: AbortSignal,
    onChunk: (text: string, model?: string, provider?: string) => void,
    onImage: (image: GeneratedImage, model?: string, provider?: string) => void,
    onDone: (truncated: boolean, model?: string, provider?: string) => void,
    onError: (msg: string) => void,
  ) {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal,
    });

    if (!res.ok) {
      let message = `HTTP ${res.status}`;
      try {
        const parsed = await res.json();
        if (typeof parsed?.error === "string") message = parsed.error;
      } catch { /* response was not JSON */ }
      throw new Error(message);
    }

    if (!res.body) throw new Error("No response body");

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let resolvedModel: string | undefined;
    let resolvedProvider: string | undefined;
    let buffer = "";
    let receivedContent = false;
    let reachedTerminalEvent = false;

    const handleEvent = (event: string): boolean => {
      const data = event
        .split("\n")
        .filter((line) => line.startsWith("data: "))
        .map((line) => line.slice(6))
        .join("\n");

      if (!data) return false;

      try {
        const parsed = JSON.parse(data);
        if (parsed.error) { reachedTerminalEvent = true; onError(parsed.error); return true; }
        if (parsed.model)    resolvedModel    = parsed.model;
        if (parsed.provider) resolvedProvider = parsed.provider;
        if (parsed.content) { receivedContent = true; onChunk(parsed.content, resolvedModel, resolvedProvider); }
        if (parsed.image?.dataUrl && parsed.image?.mimeType) {
          receivedContent = true;
          onImage(parsed.image as GeneratedImage, resolvedModel, resolvedProvider);
        }
        if (parsed.done) { reachedTerminalEvent = true; onDone(Boolean(parsed.truncated), resolvedModel, resolvedProvider); return true; }
      } catch {
        // Ignore malformed events and continue streaming.
      }
      return false;
    };

    while (true) {
      const { done, value } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });

      let eventEnd = buffer.indexOf("\n\n");
      while (eventEnd !== -1) {
        const event = buffer.slice(0, eventEnd);
        buffer = buffer.slice(eventEnd + 2);
        if (handleEvent(event)) return;
        eventEnd = buffer.indexOf("\n\n");
      }

      if (done) break;
    }

    if (buffer.trim()) handleEvent(buffer);
    if (!reachedTerminalEvent) {
      if (receivedContent) onDone(false, resolvedModel, resolvedProvider);
      else onError("The model did not return a response. Please try again or switch models.");
    }
  }

  // ─── Send message ──────────────────────────────────────────────────────
  const sendMessage = async () => {
    const content = textAttachment ? textAttachment.content : inputValue.trim();
    if ((!content && attachedImages.length === 0) || isStreaming || isProcessingImages) return;
    if (attachedImages.length > 0 && !canUploadImages) {
      setUploadError(`${selectedProviderInfo.label} does not support image uploads. Choose a vision-capable model and try again.`);
      return;
    }

    window.dispatchEvent(new CustomEvent("tts:stop"));

    setInputValue("");
    setTextAttachment(null);
    const snapshot = [...attachedImages];
    setAttachedImages([]);
    setUploadError(null);

    const userMsg: ChatMessage = {
      role: "user",
      content,
      ...(snapshot.length > 0 ? { imageDataUrls: snapshot.map(i => i.dataUrl) } : {}),
    };

    const existingMessages: ChatMessage[] = selectedConv ? selectedConv.messages : [];
    const allUserMessages: ChatMessage[] = [...existingMessages, userMsg];

    let convId = selectedId;
    let conv: StoredConversation;

    if (!convId) {
      convId = genId();
      conv = {
        id: convId,
        title: generateLocalTitle([{ role: "user", content: content || "Images" }]),
        titleGenerated: false,
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
    } else {
      conv = { ...selectedConv! };
    }

    const userMsgId = `user-${Date.now()}`;
    const assistantMsgId = `asst-${Date.now()}`;

    setSelectedId(convId);
    setStreamingMessages((prev) => [
      ...prev,
      { id: userMsgId, role: "user", content, imageDataUrls: snapshot.length > 0 ? snapshot.map(i => i.dataUrl) : undefined },
      { id: assistantMsgId, role: "assistant", content: "", streaming: true },
    ]);

    const userOnlyConv: StoredConversation = {
      ...conv,
      messages: allUserMessages,
      updatedAt: Date.now(),
    };
    setConversations((prev) => {
      const without = prev.filter((c) => c.id !== convId);
      const next = [userOnlyConv, ...without].sort((a, b) => b.updatedAt - a.updatedAt);
      saveConversations(next);
      return next;
    });

    const isFirstExchange = existingMessages.length === 0;
    if (isFirstExchange && content) {
      generateTitle(convId, content);
    }

    setIsStreaming(true);
    const controller = new AbortController();
    let requestTimedOut = false;
    const requestTimeout = window.setTimeout(() => {
      requestTimedOut = true;
      controller.abort();
    }, 70_000);
    abortRef.current = controller;

    let fullResponse = "";
    const generatedImages: GeneratedImage[] = [];
    let resolvedModel: string | undefined;
    let resolvedProvider: string | undefined;

    const activeProviderForRequest = getActiveProvider();
    const body: Record<string, unknown> = {
      messages: allUserMessages.map(m => ({ role: m.role, content: m.content })),
      provider: activeProviderForRequest,
    };
    const activeModelForRequest = getActiveModel(activeProviderForRequest, providerStatus);
    if (activeProviderForRequest !== "auto" && activeModelForRequest) body.model = activeModelForRequest;
    if (snapshot.length > 0) {
      body.images = snapshot.map(i => i.dataUrl);
      body.imageMediaTypes = snapshot.map(i => i.mimeType);
    }

    try {
      await streamResponse(
        body,
        controller.signal,
        (text, model, provider) => {
          fullResponse += text;
          if (model)    resolvedModel    = model;
          if (provider) resolvedProvider = provider;
          const captured = fullResponse;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: captured, streaming: true, resolvedModel, resolvedProvider }
              : m
            )
          );
        },
        (image, model, provider) => {
          generatedImages.push(image);
          if (model)    resolvedModel    = model;
          if (provider) resolvedProvider = provider;
          const images = [...generatedImages];
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, generatedImages: images, streaming: true, resolvedModel, resolvedProvider }
              : m
            )
          );
        },
        (truncated, model, provider) => {
          if (model)    resolvedModel    = model;
          if (provider) resolvedProvider = provider;
          const captured = fullResponse;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: captured, generatedImages: [...generatedImages], streaming: false, truncated, resolvedModel, resolvedProvider }
              : m
            )
          );
        },
        (errMsg) => {
          fullResponse = errMsg;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: errMsg, streaming: false }
              : m
            )
          );
        },
      );

      const updatedMessages: ChatMessage[] = [
        ...allUserMessages,
        { role: "assistant", content: fullResponse, ...(generatedImages.length > 0 ? { generatedImages: [...generatedImages] } : {}) },
      ];

      const updatedConv: StoredConversation = {
        ...conv,
        messages: updatedMessages,
        updatedAt: Date.now(),
      };

      setConversations((prev) => {
        const without = prev.filter((c) => c.id !== convId);
        const next = [updatedConv, ...without].sort((a, b) => b.updatedAt - a.updatedAt);
        saveConversations(next);
        return next;
      });

      // Auto-read if enabled
      const ttsPrefs = loadTtsPrefs();
      if (ttsPrefs.autoRead && fullResponse) {
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("tts:auto-read", { detail: { id: assistantMsgId, text: fullResponse } }));
        }, 100);
      }
    } catch (err: unknown) {
      if (err instanceof Error && (err.name !== "AbortError" || requestTimedOut)) {
        const errorMessage = requestTimedOut
          ? "The request took too long, so I stopped it instead of leaving the chat loading. Please try again or switch models."
          : err instanceof Error && err.message ? err.message : "Sorry, something went wrong. Please try again.";
        setStreamingMessages((prev) =>
          prev.map((m) => m.id === assistantMsgId
            ? { ...m, content: errorMessage, streaming: false }
            : m
          )
        );
        setConversations((prev) => {
          const updated = prev.map((c) => c.id === convId
            ? { ...c, messages: [...allUserMessages, { role: "assistant" as const, content: errorMessage }], updatedAt: Date.now() }
            : c
          );
          saveConversations(updated);
          return updated;
        });
      } else {
        setStreamingMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));
      }
    } finally {
      window.clearTimeout(requestTimeout);
      setIsStreaming(false);
      abortRef.current = null;
      focusChatInput();
    }
  };

  // ─── Continue generating ───────────────────────────────────────────────
  const handleContinue = useCallback(async (assistantMsgId: string, previousContent: string) => {
    if (isStreaming || !selectedConv) return;

    setStreamingMessages((prev) =>
      prev.map((m) => m.id === assistantMsgId
        ? { ...m, truncated: false, streaming: true }
        : m
      )
    );
    setIsStreaming(true);

    const controller = new AbortController();
    let requestTimedOut = false;
    const requestTimeout = window.setTimeout(() => {
      requestTimedOut = true;
      controller.abort();
    }, 70_000);
    abortRef.current = controller;

    const convMessages = selectedConv.messages.map(m => ({ role: m.role, content: m.content }));
    let continuationContent = previousContent;
    let resolvedModel: string | undefined;

    const activeProviderForRequest = getActiveProvider();
    const body: Record<string, unknown> = {
      messages: convMessages,
      provider: activeProviderForRequest,
      isContinuation: true,
      previousContent,
    };
    const activeModelForRequest = getActiveModel(activeProviderForRequest, providerStatus);
    if (activeProviderForRequest !== "auto" && activeModelForRequest) body.model = activeModelForRequest;

    try {
      await streamResponse(
        body,
        controller.signal,
        (text, model) => {
          continuationContent += text;
          if (model) resolvedModel = model;
          const captured = continuationContent;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: captured, streaming: true, resolvedModel }
              : m
            )
          );
        },
        () => {
          // Continuation requests only append text to an existing assistant message.
        },
        (truncated, model) => {
          if (model) resolvedModel = model;
          const captured = continuationContent;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: captured, streaming: false, truncated, resolvedModel }
              : m
            )
          );
        },
        (errMsg) => {
          continuationContent = `${previousContent}\n\n*${errMsg}*`;
          setStreamingMessages((prev) =>
            prev.map((m) => m.id === assistantMsgId
              ? { ...m, content: continuationContent, streaming: false }
              : m
            )
          );
        },
      );

      // Update stored conversation
      setConversations((prev) => {
        const updated = prev.map((c) => {
          if (c.id !== selectedId) return c;
          const msgs = [...c.messages];
          const lastIdx = msgs.length - 1;
          if (lastIdx >= 0 && msgs[lastIdx].role === "assistant") {
            msgs[lastIdx] = { ...msgs[lastIdx], content: continuationContent };
          }
          const u = { ...c, messages: msgs, updatedAt: Date.now() };
          return u;
        });
        saveConversations(updated);
        return updated;
      });
    } catch (err: unknown) {
      if (!(err instanceof Error) || err.name !== "AbortError" || requestTimedOut) {
        const errorMessage = requestTimedOut
          ? "Continuation took too long, so I stopped it instead of leaving the chat loading."
          : "Continuation failed. Please try again.";
        setStreamingMessages((prev) =>
          prev.map((m) => m.id === assistantMsgId
            ? { ...m, content: `${previousContent}\n\n*${errorMessage}*`, streaming: false }
            : m
          )
        );
      }
    } finally {
      window.clearTimeout(requestTimeout);
      setIsStreaming(false);
      abortRef.current = null;
      focusChatInput();
    }
  }, [focusChatInput, isStreaming, providerStatus, selectedConv, selectedId]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (val.length > TEXT_ATTACHMENT_THRESHOLD) {
      convertToTextAttachment(val);
    } else {
      setInputValue(val);
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const pasted = e.clipboardData.getData("text");
    const combined = inputValue + pasted;
    if (combined.length > TEXT_ATTACHMENT_THRESHOLD) {
      e.preventDefault();
      convertToTextAttachment(combined);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.ctrlKey && !e.shiftKey && !e.metaKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleStop = () => { abortRef.current?.abort(); };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">

      {/* Full-width top bar — single border-b across the entire width */}
      <header className="h-14 flex-shrink-0 border-b border-border flex items-center gap-3 px-3">
        {/* Brand area — desktop only, matches sidebar width exactly */}
        <button
          onClick={() => setLocation("/")}
          className="hidden md:flex items-center gap-2 px-2 py-1 rounded-lg hover:bg-accent transition-colors flex-shrink-0"
          style={{ width: "calc(16rem - 1.5rem)" }}
        >
          <div
            className="w-6 h-6 rounded-md flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))", boxShadow: "0 0 10px hsl(var(--primary)/0.4)" }}
          >
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-sm font-semibold">4trio</span>
        </button>

        {/* Mobile hamburger */}
        <button
          data-testid="open-sidebar"
          onClick={() => setSidebarOpen(true)}
          className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
        >
          <Menu className="w-4 h-4" />
        </button>

        {/* Conversation title */}
        <div className="flex-1 min-w-0 px-1">
          {selectedConv ? (
            <span className="text-sm font-medium truncate block">{selectedConv.title}</span>
          ) : (
            <span className="text-sm text-muted-foreground">New conversation</span>
          )}
        </div>

        <StatusDot isStreaming={isStreaming} />

        {selectedId && (
          <button
            data-testid="new-chat-topbar"
            onClick={handleNewChat}
            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            title="New chat"
          >
            <Plus className="w-4 h-4" />
          </button>
        )}
      </header>

      {/* Content row — sidebar + main */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 bg-black/50 z-20 md:hidden"
            />
          )}
        </AnimatePresence>

        {/* Sidebar — same background as main; no border, no shadow, no colour gap */}
        <aside
          className={`fixed top-14 bottom-0 left-0 z-30 w-64 flex-shrink-0 flex flex-col bg-background transition-transform duration-200 md:static md:top-auto md:bottom-auto md:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="p-3 border-b border-border/[0.08] flex items-center gap-2">
            <button
              data-testid="new-chat-btn"
              onClick={handleNewChat}
              className="flex-1 flex items-center gap-2 px-3 py-2.5 rounded-lg border border-border/[0.15] hover:bg-sidebar-accent transition-colors text-sm font-medium text-sidebar-foreground"
            >
              <Plus className="w-4 h-4" />
              New chat
            </button>
            <button
              data-testid="close-sidebar"
              onClick={() => setSidebarOpen(false)}
              className="md:hidden p-1.5 rounded-lg hover:bg-sidebar-accent transition-colors flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

        {/* Search */}
        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-b border-border/[0.08]"
            >
              <div className="p-2">
                <input
                  ref={searchInputRef}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search conversations…"
                  className="w-full px-3 py-2 bg-muted rounded-lg text-sm outline-none focus:ring-1 focus:ring-primary/30"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex-1 overflow-y-auto scrollbar-thin py-2">
          {filteredConversations.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <MessageSquare className="w-8 h-8 text-muted-foreground/70 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">{searchQuery ? "No results" : "No conversations yet"}</p>
            </div>
          ) : (
            <div className="space-y-0.5 px-2">
              {filteredConversations.map((conv) => (
                <div
                  key={conv.id}
                  data-testid={`conversation-item-${conv.id}`}
                  onClick={() => { if (renamingConvId !== conv.id) selectConversation(conv.id); }}
                  onMouseEnter={() => setHoveredConvId(conv.id)}
                  onMouseLeave={() => setHoveredConvId(null)}
                  className={`group flex items-center gap-1.5 px-3 py-2.5 rounded-lg cursor-pointer transition-colors text-sm ${
                    selectedId === conv.id
                      ? "text-sidebar-accent-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                  }`}
                  style={selectedId === conv.id ? {
                    background: "hsl(var(--primary)/0.1)",
                    borderLeft: "2px solid hsl(var(--primary))",
                  } : {}}
                >
                  <MessageSquare className="w-3.5 h-3.5 flex-shrink-0 opacity-60" />
                  {renamingConvId === conv.id ? (
                    <input
                      autoFocus
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onBlur={() => commitRename(conv.id)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") { e.preventDefault(); commitRename(conv.id); }
                        if (e.key === "Escape") setRenamingConvId(null);
                        e.stopPropagation();
                      }}
                      onClick={(e) => e.stopPropagation()}
                      className="flex-1 min-w-0 bg-transparent text-sm outline-none border-b border-primary pb-0.5"
                    />
                  ) : (
                    <span className="flex-1 truncate min-w-0">{conv.title}</span>
                  )}
                  <div className={`flex items-center gap-0.5 flex-shrink-0 transition-opacity ${hoveredConvId === conv.id ? "opacity-100" : "opacity-0"}`}>
                    <button
                      data-testid={`rename-conv-${conv.id}`}
                      onClick={(e) => startRename(e, conv.id, conv.title)}
                      className="p-1 rounded hover:bg-sidebar-accent transition-colors text-muted-foreground hover:text-foreground"
                      title="Rename"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button
                      data-testid={`delete-conv-${conv.id}`}
                      onClick={(e) => handleDelete(e, conv.id)}
                      className="p-1 rounded hover:bg-destructive/20 hover:text-destructive transition-colors text-muted-foreground"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-3 border-t border-border/[0.08] space-y-1">
          <button
            onClick={() => setSearchOpen((p) => !p)}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-sidebar-accent transition-colors text-sm text-sidebar-foreground"
          >
            <Search className="w-4 h-4 opacity-60" />
            Search
          </button>
          <button
            data-testid="settings-btn"
            onClick={() => setLocation("/settings")}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg hover:bg-sidebar-accent transition-colors text-sm text-sidebar-foreground"
          >
            <Settings className="w-4 h-4 opacity-60" />
            Settings
          </button>
        </div>
      </aside>

        {/* Main content — no header inside; the top-level header spans full width */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Messages */}
        <div className="flex-1 overflow-y-auto scrollbar-thin px-4 py-6 relative">
          {streamingMessages.length === 0 ? (
            <div className="min-h-full flex flex-col items-center justify-center max-w-lg mx-auto text-center relative py-6 px-1">
              <div className="pointer-events-none absolute inset-0 overflow-hidden">
                <div
                  className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full"
                  style={{ background: "radial-gradient(ellipse, hsl(var(--primary)/0.12) 0%, transparent 70%)", filter: "blur(40px)", animation: "pulse 5s ease-in-out infinite" }}
                />
                <div
                  className="absolute bottom-1/3 left-1/4 w-48 h-48 rounded-full"
                  style={{ background: "radial-gradient(ellipse, rgba(79,70,229,0.08) 0%, transparent 70%)", filter: "blur(50px)" }}
                />
              </div>

              <motion.div
                initial={{ opacity: 0, scale: 0.92, y: 12 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="relative z-10 w-full"
              >
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="w-14 h-14 sm:w-20 sm:h-20 rounded-2xl sm:rounded-3xl mx-auto mb-3 sm:mb-5 flex items-center justify-center"
                  style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))", boxShadow: "0 0 48px hsl(var(--primary)/0.4), 0 8px 32px rgba(0,0,0,0.25)" }}
                >
                  <Sparkles className="w-6 h-6 sm:w-9 sm:h-9 text-white drop-shadow" />
                </motion.div>

                <motion.p
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05, type: "spring", stiffness: 380, damping: 30 }}
                  className="text-xs sm:text-sm text-muted-foreground mb-0.5 sm:mb-1"
                >
                  {getGreeting()} 👋
                </motion.p>
                <motion.h2
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1, type: "spring", stiffness: 380, damping: 30 }}
                  className="text-xl sm:text-3xl font-bold tracking-tight mb-1.5 sm:mb-2"
                >
                  <span
                    className="bg-clip-text text-transparent"
                    style={{ backgroundImage: "linear-gradient(90deg, hsl(var(--primary)), hsl(var(--primary)/0.7), hsl(var(--primary)/0.9))" }}
                  >
                    What can I help with?
                  </span>
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.18 }}
                  className="text-muted-foreground/70 text-xs sm:text-sm mb-1"
                >
                  {getActiveProviderInfo().label}
                </motion.p>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.22 }}
                  className="text-muted-foreground/70 text-xs mb-5 sm:mb-8"
                >
                  {selectedProviderInfo.desc}
                </motion.p>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-2.5 text-left">
                  {suggestedPrompts.map((prompt, i) => (
                    <motion.button
                      key={prompt}
                      initial={{ opacity: 0, y: 14, scale: 0.97 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ delay: 0.18 + i * 0.06, type: "spring", stiffness: 360, damping: 28 }}
                      whileHover={{ scale: 1.025, y: -2, transition: { type: "spring", stiffness: 500, damping: 28 } }}
                      whileTap={{ scale: 0.97, transition: { duration: 0.1 } }}
                      data-testid="suggested-prompt"
                      onClick={() => { setInputValue(prompt); textareaRef.current?.focus(); }}
                      className="px-4 py-3.5 rounded-xl text-sm text-left leading-relaxed min-h-[72px] sm:min-h-[84px] flex items-center"
                      style={{
                        border: "1px solid hsl(var(--primary)/0.18)",
                        background: "hsl(var(--primary)/0.04)",
                        color: "inherit",
                        transition: "border-color 0.18s, background 0.18s, box-shadow 0.18s",
                        willChange: "transform",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = "hsl(var(--primary)/0.45)";
                        e.currentTarget.style.background = "hsl(var(--primary)/0.09)";
                        e.currentTarget.style.boxShadow = "0 4px 20px hsl(var(--primary)/0.12)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = "hsl(var(--primary)/0.18)";
                        e.currentTarget.style.background = "hsl(var(--primary)/0.04)";
                        e.currentTarget.style.boxShadow = "";
                      }}
                    >
                      {prompt}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto space-y-6">
              <AnimatePresence initial={false}>
                {streamingMessages.map((msg) => (
                  <MessageBubble
                    key={msg.id}
                    msg={msg}
                    isStreamingAnything={isStreaming}
                    onContinue={msg.truncated && !msg.streaming && msg.role === "assistant"
                      ? () => handleContinue(msg.id, msg.content)
                      : undefined
                    }
                  />
                ))}
              </AnimatePresence>
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input area */}
        <div className="border-t border-border px-4 py-4 flex-shrink-0">
          <div className="max-w-2xl mx-auto space-y-2">
            {textAttachment && (
              <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-border bg-muted/30 text-sm">
                <FileText className="w-4 h-4 text-primary/70 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-foreground/90 truncate text-xs font-medium">{textAttachment.preview}</div>
                  <div className="text-muted-foreground text-[11px] mt-0.5">{textAttachment.lineCount} line{textAttachment.lineCount !== 1 ? "s" : ""} · {textAttachment.charCount} chars</div>
                </div>
                <button
                  onClick={() => { setInputValue(textAttachment.content); setTextAttachment(null); requestAnimationFrame(() => textareaRef.current?.focus()); }}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted flex-shrink-0"
                  title="Edit text"
                >
                  Edit
                </button>
                <button
                  onClick={() => setTextAttachment(null)}
                  className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
                  title="Remove"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {attachedImages.length > 0 && (
              <div className="flex flex-wrap gap-2 items-start">
                {attachedImages.map((img, i) => (
                  <div key={i} className="relative inline-block">
                    <img src={img.dataUrl} alt={`Attached ${i + 1}`} className="h-16 w-16 rounded-xl object-cover border border-border" />
                    <button
                      onClick={() => setAttachedImages(prev => prev.filter((_, idx) => idx !== i))}
                      className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-background border border-border flex items-center justify-center hover:bg-muted transition-colors shadow-sm"
                      title="Remove image"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground self-center">
                  <span className="text-primary font-medium">{attachedImages.length}/{maxImages} images</span>
                  {attachedImages.length >= maxImages && <span className="text-muted-foreground/75">· max reached</span>}
                </div>
              </div>
            )}

            {uploadError && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                {uploadError}
              </div>
            )}
            {isProcessingImages && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="w-3 h-3 animate-spin" />
                Preparing image preview…
              </div>
            )}

            <div
              className="flex items-center gap-3 bg-card border border-border rounded-2xl px-4 py-3"
              style={{ transition: "border-color 0.2s, box-shadow 0.2s" }}
              onFocusCapture={(e) => {
                e.currentTarget.style.borderColor = "hsl(var(--primary)/0.55)";
                e.currentTarget.style.boxShadow = "0 0 0 3px hsl(var(--primary)/0.12), 0 4px 20px hsl(var(--primary)/0.08)";
              }}
              onBlurCapture={(e) => {
                if (!e.currentTarget.contains(e.relatedTarget as Node)) {
                  e.currentTarget.style.borderColor = "";
                  e.currentTarget.style.boxShadow = "";
                }
              }}
            >
              <input ref={fileInputRef} type="file" accept="image/*" multiple={maxImages !== 1} className="hidden" onChange={handleImageSelect} />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isStreaming || isRecording || isProcessingImages || !canUploadImages || attachedImages.length >= maxImages}
                className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors disabled:opacity-30 disabled:cursor-not-allowed relative"
                title={attachedImages.length >= maxImages ? canUploadImages ? `Max ${maxImages} image${maxImages === 1 ? "" : "s"}` : "Images are not supported by this model" : "Attach images"}
              >
                <Paperclip className="w-4 h-4" />
                {attachedImages.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 rounded-full text-white text-[9px] font-bold flex items-center justify-center bg-primary">
                    {attachedImages.length}
                  </span>
                )}
              </button>

              <textarea
                ref={textareaRef}
                data-testid="chat-input"
                value={inputValue}
                onChange={handleInputChange}
                onPaste={handlePaste}
                onKeyDown={handleKeyDown}
                placeholder={
                  textAttachment ? "Add a note… (optional)" :
                  isRecording ? "Recording… click mic to stop" :
                  isTranscribing ? "Transcribing…" :
                  "Message 4trio..."
                }
                rows={1}
                disabled={isStreaming && !isRecording}
                className="flex-1 min-w-0 bg-transparent resize-none outline-none text-base sm:text-sm placeholder:text-muted-foreground/70 max-h-[200px] disabled:opacity-60"
                style={{ lineHeight: "1.5" }}
              />

              <button
                onClick={handleMicClick}
                disabled={isStreaming || isTranscribing}
                title={isRecording ? "Stop recording" : "Voice input"}
                className={`flex-shrink-0 transition-colors disabled:opacity-30 disabled:cursor-not-allowed ${
                  isRecording ? "text-red-400 animate-pulse" :
                  isTranscribing ? "text-yellow-400" :
                  "text-muted-foreground hover:text-foreground"
                }`}
              >
                {isTranscribing ? <Loader2 className="w-4 h-4 animate-spin" /> :
                 isRecording ? <MicOff className="w-4 h-4" /> :
                 <Mic className="w-4 h-4" />}
              </button>

              {isStreaming ? (
                <button
                  onClick={handleStop}
                  title="Stop generating"
                  className="flex-shrink-0 p-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              ) : (
                <motion.button
                  onClick={sendMessage}
                  disabled={(!inputValue.trim() && !textAttachment && attachedImages.length === 0) || isStreaming || isProcessingImages}
                  title="Send message"
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.91 }}
                  transition={{ type: "spring", stiffness: 500, damping: 28 }}
                  className="flex-shrink-0 p-1.5 rounded-lg bg-primary text-primary-foreground disabled:opacity-30 disabled:cursor-not-allowed"
                  style={{ boxShadow: "0 0 12px hsl(var(--primary)/0.45)" }}
                >
                  <Send className="w-4 h-4" />
                </motion.button>
              )}
            </div>

            <p className="text-center text-[10px] text-muted-foreground/60">
              4trio can make mistakes. Verify important information.
            </p>
          </div>
        </div>
        </main>
      </div>
    </div>
  );
}
