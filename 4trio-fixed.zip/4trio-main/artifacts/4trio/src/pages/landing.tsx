import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ChevronRight, Sparkles, Zap, ExternalLink } from "lucide-react";
import { completeOnboarding } from "@/lib/onboarding";
import { usePageMeta } from "@/hooks/use-page-meta";

const features = [
  {
    num: "01",
    color: "hsl(var(--primary))",
    colorRgb: "var(--primary)",
    tag: "Speed",
    title: "Lightning Fast",
    desc: "Groq inference delivers tokens in milliseconds — not seconds. Responses feel instant, no matter the complexity.",
  },
  {
    num: "02",
    color: "#2563eb",
    colorRgb: "37,99,235",
    tag: "Memory",
    title: "Persistent History",
    desc: "Every conversation is saved in your browser. Pick up where you left off, continue a thread, or review past answers anytime.",
  },
  {
    num: "03",
    color: "#059669",
    colorRgb: "5,150,105",
    tag: "Privacy",
    title: "No Account Needed",
    desc: "No sign-up, no login, no tracking. Open the app and start chatting immediately. Your history stays in your browser.",
  },
  {
    num: "04",
    color: "#d97706",
    colorRgb: "217,119,6",
    tag: "AI Models",
    title: "Top-tier Intelligence",
    desc: "Powered by frontier models from Meta and Google — always available, always fast.",
  },
  {
    num: "05",
    color: "#db2777",
    colorRgb: "219,39,119",
    tag: "Streaming",
    title: "Real-time Responses",
    desc: "Answers stream token-by-token via SSE. Watch the AI think in real time, not all at once.",
  },
  {
    num: "06",
    color: "#0891b2",
    colorRgb: "8,145,178",
    tag: "Interface",
    title: "Rich Markdown Output",
    desc: "Bold, code blocks, lists, syntax highlighting — AI answers render as clean, readable content.",
  },
];

export default function Landing() {
  usePageMeta({
    title: "4trio — Free AI Chat Powered by Groq | No Login Required",
    description: "4trio is a free AI chat app powered by Groq. Instantly chat with Llama 4, Gemini Flash, and other frontier models. No account, no tracking — just open and talk to AI.",
    canonical: "https://4trio.up.railway.app/",
    ogImage: "https://4trio.up.railway.app/opengraph.jpg",
  });

  const [, setLocation] = useLocation();

  const startChatting = () => {
    completeOnboarding();
    setLocation("/chat");
  };

  return (
    <div className="min-h-screen bg-[#030308] text-white overflow-x-hidden relative">
      {/* Ambient glow orbs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div
          className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[600px] rounded-full opacity-20"
          style={{
            background: "radial-gradient(ellipse, hsl(var(--primary)) 0%, hsl(var(--primary)/0.5) 40%, transparent 70%)",
            filter: "blur(60px)",
          }}
        />
        <div
          className="absolute top-1/3 -left-60 w-[500px] h-[500px] rounded-full opacity-10"
          style={{
            background: "radial-gradient(ellipse, hsl(var(--primary)/0.8) 0%, transparent 70%)",
            filter: "blur(80px)",
          }}
        />
        <div
          className="absolute top-1/2 -right-60 w-[500px] h-[500px] rounded-full opacity-10"
          style={{
            background: "radial-gradient(ellipse, hsl(var(--primary)/0.6) 0%, transparent 70%)",
            filter: "blur(80px)",
          }}
        />
      </div>

      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 border-b border-white/5 bg-black/40 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))",
                boxShadow: "0 0 20px hsl(var(--primary)/0.5)",
              }}
            >
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-semibold tracking-tight">4trio</span>
          </div>
          <button
            data-testid="nav-get-started"
            onClick={startChatting}
            className="text-sm px-4 py-2 rounded-lg text-white font-medium transition-all hover:scale-[1.03]"
            style={{
              background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))",
              boxShadow: "0 0 16px hsl(var(--primary)/0.4)",
            }}
          >
            Start chatting
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 sm:pt-36 pb-20 sm:pb-24 px-4 sm:px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-6 sm:mb-8 border"
              style={{
                border: "1px solid hsl(var(--primary)/0.4)",
                background: "hsl(var(--primary)/0.12)",
                color: "hsl(var(--primary))",
                boxShadow: "0 0 20px hsl(var(--primary)/0.15)",
              }}
            >
              <Zap className="w-3 h-3" />
              Powered by Groq — Ultra-fast AI
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight leading-none mb-5 sm:mb-6">
              4trio — Chat with AI that
              <br />
              <span
                className="bg-clip-text text-transparent"
                style={{
                  backgroundImage: "linear-gradient(90deg, hsl(var(--primary)), hsl(var(--primary)/0.7), hsl(var(--primary)/0.9))",
                  filter: "drop-shadow(0 0 30px hsl(var(--primary)/0.5))",
                }}
              >
                actually thinks fast
              </span>
            </h1>

            <p className="text-base sm:text-lg text-white/50 max-w-xl mx-auto mb-8 sm:mb-10 leading-relaxed">
              4trio gives you a clean, powerful interface to the world's fastest AI models.
              No account required. Just{" "}
              <button onClick={startChatting} className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors">
                open and chat
              </button>.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                data-testid="hero-start-chat"
                onClick={startChatting}
                className="w-full sm:w-auto flex items-center justify-center gap-2 text-white px-8 py-3.5 rounded-xl text-base font-semibold transition-all hover:scale-[1.03] active:scale-[0.98]"
                style={{
                  background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))",
                  boxShadow: "0 0 32px hsl(var(--primary)/0.5), 0 4px 20px rgba(0,0,0,0.4)",
                }}
              >
                Start chatting now
                <ChevronRight className="w-4 h-4" />
              </button>
              <button
                data-testid="hero-learn-more"
                onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl text-base font-medium border border-white/10 bg-white/5 hover:bg-white/10 transition-colors text-white/70 hover:text-white"
              >
                Learn more
              </button>
            </div>
          </motion.div>

          {/* Chat preview mockup */}
          <motion.div
            initial={{ opacity: 0, y: 48 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25, ease: "easeOut" }}
            className="mt-12 sm:mt-16 relative"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#030308] z-10 pointer-events-none" style={{ top: "55%" }} />
            <div
              className="rounded-2xl overflow-hidden text-left"
              style={{
                border: "1px solid hsl(var(--primary)/0.3)",
                background: "rgba(15,10,30,0.8)",
                boxShadow: "0 0 60px hsl(var(--primary)/0.15), 0 25px 60px rgba(0,0,0,0.5)",
              }}
            >
              <div
                className="border-b px-4 py-3 flex items-center gap-2"
                style={{ borderColor: "hsl(var(--primary)/0.2)", background: "hsl(var(--primary)/0.05)" }}
              >
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
                <span className="ml-2 text-xs text-white/30 font-mono">4trio — New conversation</span>
              </div>
              <div className="p-6 space-y-4 font-mono text-sm">
                <div className="flex justify-end">
                  <div
                    className="rounded-2xl rounded-tr-sm px-4 py-2.5 max-w-xs text-sm text-white"
                    style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))" }}
                  >
                    Explain quantum entanglement simply
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: "hsl(var(--primary)/0.2)", boxShadow: "0 0 10px hsl(var(--primary)/0.3)" }}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <div
                    className="rounded-2xl rounded-tl-sm px-4 py-2.5 max-w-md text-sm text-white/60 leading-relaxed"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.07)" }}
                  >
                    Quantum entanglement is like having two magic coins — when you flip one and it lands heads, the other instantly lands tails, no matter how far apart they are...
                    <span
                      className="inline-block w-2 h-4 ml-1 animate-pulse rounded-sm bg-primary"
                    />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 sm:py-24 px-4 sm:px-6 relative" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="mb-12 sm:mb-16"
          >
            <p className="text-xs text-white/30 uppercase tracking-widest font-medium mb-3">What you get</p>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">
              Built different.{" "}
              <span className="text-white/30">Every detail matters.</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px"
            style={{ background: "rgba(255,255,255,0.05)", borderRadius: "16px", overflow: "hidden" }}>
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="relative p-6 sm:p-7 group cursor-default transition-all"
                style={{ background: "#030308" }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget as HTMLDivElement;
                  if (f.colorRgb === "var(--primary)") {
                    el.style.background = "hsl(var(--primary)/0.06)";
                  } else {
                    el.style.background = `rgba(${f.colorRgb},0.06)`;
                  }
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = "#030308";
                }}
              >
                <div className="absolute top-0 left-7 right-7 h-px" style={{ background: `linear-gradient(90deg, ${f.color}60, transparent)` }} />
                <div className="flex items-center justify-between mb-4 sm:mb-5">
                  <span
                    className="text-xs font-semibold px-2 py-1 rounded-md"
                    style={{ color: f.color, background: `${f.color === "hsl(var(--primary))" ? "hsl(var(--primary)/0.12)" : f.color + "18"}` }}
                  >
                    {f.tag}
                  </span>
                  <span className="text-2xl font-bold tabular-nums" style={{ color: `${f.color === "hsl(var(--primary))" ? "hsl(var(--primary)/0.25)" : f.color + "30"}` }}>{f.num}</span>
                </div>
                <h3 className="text-base font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-sm text-white/40 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About / AEO content section */}
      <section id="about" className="py-20 sm:py-24 px-4 sm:px-6 relative" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-xs text-white/30 uppercase tracking-widest font-medium mb-3">About 4trio</p>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-8">
              The fastest free AI chat,{" "}
              <span className="text-white/30">explained.</span>
            </h2>

            <div className="space-y-6 text-white/55 leading-relaxed text-sm sm:text-base">
              <p>
                <strong className="text-white/80">4trio</strong> is a free AI chat platform built for people who want real answers — fast. Unlike traditional chatbots that keep you waiting, 4trio is powered by{" "}
                <a
                  href="https://groq.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80 inline-flex items-center gap-0.5 underline underline-offset-2 transition-colors"
                >
                  Groq's Language Processing Unit (LPU)<ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>{" "}
                — purpose-built silicon that delivers AI inference at a fundamentally different speed. You can ask a question and see a complete answer stream in under a second.
              </p>

              <p>
                The app gives you access to several frontier AI models in one place. On the text side, 4trio supports{" "}
                <a
                  href="https://ai.meta.com/blog/llama-4-multimodal-intelligence/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80 inline-flex items-center gap-0.5 underline underline-offset-2 transition-colors"
                >
                  Meta's Llama 4 Scout<ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>{" "}
                (a 17B-parameter multimodal model with a 10M token context window) alongside large coding models and reasoning variants. For vision and image generation, 4trio integrates{" "}
                <a
                  href="https://deepmind.google/technologies/gemini/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80 inline-flex items-center gap-0.5 underline underline-offset-2 transition-colors"
                >
                  Google Gemini Flash<ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>{" "}
                — capable of understanding images you upload and generating new images from text descriptions.
              </p>

              <p>
                Privacy is a first-class concern. 4trio requires no account, no email, and no login of any kind.{" "}
                <button onClick={startChatting} className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors">
                  Start a conversation
                </button>{" "}
                and your full history is stored locally in your browser's IndexedDB — never on a server tied to your identity. You can clear it at any time from the{" "}
                <button
                  onClick={() => { completeOnboarding(); setLocation("/settings"); }}
                  className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors"
                >
                  settings page
                </button>.
              </p>

              <p>
                Beyond plain text, 4trio supports voice input (speech-to-text via Whisper), text-to-speech playback, image uploads for vision analysis (up to 16 images per message with Gemini), and rich Markdown rendering with full syntax highlighting for code. The interface is a Progressive Web App — you can install 4trio on your phone or desktop and use it offline for browsing past conversations.
              </p>

              <p>
                4trio was created by Labib as a demonstration of what a modern AI interface should feel like: opinionated, fast, and user-first. The "Auto" mode intelligently routes your message to the best available provider — so you never have to manually pick a model unless you want to. Whether you're{" "}
                <button onClick={startChatting} className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors">
                  debugging code
                </button>,
                {" "}drafting an email, or just exploring ideas, 4trio handles it in the time it takes you to finish your thought.
              </p>

              <p>
                The platform is completely free to use. There are no paywalls, no usage tiers, and no hidden limits. The goal is simple: give everyone access to the best AI tools, without friction.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-3 gap-4 text-center">
              {[
                { stat: "< 1s", label: "Avg. first token" },
                { stat: "6+", label: "AI providers" },
                { stat: "100%", label: "Free forever" },
              ].map(({ stat, label }) => (
                <div
                  key={label}
                  className="rounded-xl p-4 sm:p-5"
                  style={{ border: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.03)" }}
                >
                  <div className="text-xl sm:text-2xl font-bold text-primary mb-1">{stat}</div>
                  <div className="text-xs text-white/35">{label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 sm:py-24 px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mx-auto text-center rounded-2xl p-8 sm:p-12 relative overflow-hidden"
          style={{
            border: "1px solid hsl(var(--primary)/0.3)",
            background: "hsl(var(--primary)/0.06)",
            boxShadow: "0 0 60px hsl(var(--primary)/0.12)",
          }}
        >
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "radial-gradient(ellipse at 50% 0%, hsl(var(--primary)/0.15) 0%, transparent 70%)",
            }}
          />
          <Sparkles
            className="w-8 h-8 mx-auto mb-4 text-primary"
            style={{ filter: "drop-shadow(0 0 8px hsl(var(--primary)/0.8))" }}
          />
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-4 text-white">Ready to start?</h2>
          <p className="text-white/40 mb-8">
            No account. No setup. Jump straight in — 4trio is free, fast, and available right now.
          </p>
          <button
            data-testid="cta-start"
            onClick={startChatting}
            className="inline-flex items-center gap-2 text-white px-8 py-3.5 rounded-xl text-base font-semibold transition-all hover:scale-[1.03] active:scale-[0.98]"
            style={{
              background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))",
              boxShadow: "0 0 32px hsl(var(--primary)/0.5), 0 4px 20px rgba(0,0,0,0.3)",
            }}
          >
            Start chatting now <ChevronRight className="w-4 h-4" />
          </button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 sm:px-6" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-sm">
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary)/0.75))" }}
            >
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="text-white/40">4trio</span>
          </div>
          <nav aria-label="Footer navigation" className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-white/25 text-xs">
            <button onClick={startChatting} className="hover:text-white/50 transition-colors">Chat</button>
            <button onClick={() => { completeOnboarding(); setLocation("/settings"); }} className="hover:text-white/50 transition-colors">Settings</button>
            <a href="https://groq.com" target="_blank" rel="noopener noreferrer" className="hover:text-white/50 transition-colors inline-flex items-center gap-0.5">
              Powered by Groq <ExternalLink className="w-2.5 h-2.5" />
            </a>
            <span>·</span>
            <span>© 2026 4trio</span>
          </nav>
        </div>
      </footer>
    </div>
  );
}
