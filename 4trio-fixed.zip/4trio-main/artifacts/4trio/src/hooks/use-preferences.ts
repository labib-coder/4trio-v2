export type ThemeId = "violet" | "sapphire" | "emerald" | "rose" | "amber" | "slate";
export type FontId = "inter" | "system" | "mono";

export interface Preferences {
  theme: ThemeId;
  font: FontId;
  fontSize: number;
}

export interface TtsPrefs {
  autoRead: boolean;
  voiceURI: string;
  rate: number;
  pitch: number;
  useNaturalVoice: boolean;
}

const DEFAULT_TTS: TtsPrefs = {
  autoRead: false,
  voiceURI: "",
  rate: 1.0,
  pitch: 1.0,
  useNaturalVoice: false,
};

const TTS_KEY = "4trio-tts-prefs";

export function loadTtsPrefs(): TtsPrefs {
  try {
    const raw = localStorage.getItem(TTS_KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<TtsPrefs>;
      return {
        autoRead: typeof p.autoRead === "boolean" ? p.autoRead : DEFAULT_TTS.autoRead,
        voiceURI: typeof p.voiceURI === "string" ? p.voiceURI : DEFAULT_TTS.voiceURI,
        rate: typeof p.rate === "number" ? Math.max(0.5, Math.min(2, p.rate)) : DEFAULT_TTS.rate,
        pitch: typeof p.pitch === "number" ? Math.max(0.5, Math.min(2, p.pitch)) : DEFAULT_TTS.pitch,
        useNaturalVoice: typeof p.useNaturalVoice === "boolean" ? p.useNaturalVoice : DEFAULT_TTS.useNaturalVoice,
      };
    }
  } catch {}
  return { ...DEFAULT_TTS };
}

export function saveTtsPrefs(prefs: TtsPrefs) {
  localStorage.setItem(TTS_KEY, JSON.stringify(prefs));
}

const PREFS_VERSION = 3; // bump when default fontSize changes — clears old stored values
const DEFAULT: Preferences = { theme: "emerald", font: "inter", fontSize: 100 };

const THEMES: Record<ThemeId, { primary: string; label: string; hex: string }> = {
  violet:   { primary: "258 90% 66%", label: "Violet",  hex: "#7c3aed" },
  sapphire: { primary: "217 91% 60%", label: "Sapphire", hex: "#3b82f6" },
  emerald:  { primary: "160 84% 39%", label: "Emerald", hex: "#10b981" },
  rose:     { primary: "347 77% 60%", label: "Rose",    hex: "#f43f5e" },
  amber:    { primary: "38 92% 52%",  label: "Amber",   hex: "#f59e0b" },
  slate:    { primary: "215 25% 60%", label: "Slate",   hex: "#64748b" },
};

const FONTS: Record<FontId, { css: string; label: string; sample: string }> = {
  inter:  { css: "'Inter', sans-serif",              label: "Inter",  sample: "The quick brown fox" },
  system: { css: "system-ui, -apple-system, sans-serif", label: "System", sample: "The quick brown fox" },
  mono:   { css: "'JetBrains Mono', monospace",      label: "Mono",   sample: "The quick brown fox" },
};

export { THEMES, FONTS };

export function loadPreferences(): Preferences {
  try {
    const raw = localStorage.getItem("4trio-prefs");
    if (raw) {
      const parsed = JSON.parse(raw) as Record<string, unknown>;

      // Version migration: if stored version doesn't match, reset fontSize to 100
      const storedVersion = typeof parsed.version === "number" ? parsed.version : 0;
      const fontSize = storedVersion >= PREFS_VERSION
        ? (typeof parsed.fontSize === "number" && parsed.fontSize >= 75 && parsed.fontSize <= 150
            ? parsed.fontSize
            : DEFAULT.fontSize)
        : DEFAULT.fontSize; // reset on version mismatch

      const storedTheme = (parsed.theme && typeof parsed.theme === "string" && parsed.theme in THEMES)
        ? parsed.theme as ThemeId
        : DEFAULT.theme;
      const migrated = !localStorage.getItem("4trio-theme-v2");
      const theme = (migrated && storedTheme === "violet") ? DEFAULT.theme : storedTheme;
      if (migrated) localStorage.setItem("4trio-theme-v2", "1");
      return {
        theme,
        font: (parsed.font && typeof parsed.font === "string" && parsed.font in FONTS) ? parsed.font as FontId : DEFAULT.font,
        fontSize,
      };
    }
  } catch {}
  return { ...DEFAULT };
}

export function applyPreferences(prefs: Preferences) {
  const root = document.documentElement;
  const theme = THEMES[prefs.theme];
  const font  = FONTS[prefs.font];

  root.style.setProperty("--primary", theme.primary);
  root.style.setProperty("--ring", theme.primary);
  root.style.setProperty("--sidebar-primary", theme.primary);
  root.style.setProperty("--sidebar-ring", theme.primary);

  const [h] = theme.primary.split(" ");
  root.style.setProperty("--accent", `${h} 20% 18%`);
  root.style.setProperty("--accent-foreground", `${h} 80% 80%`);
  root.style.setProperty("--sidebar-accent", `${h} 20% 18%`);
  root.style.setProperty("--sidebar-accent-foreground", `${h} 80% 80%`);

  root.style.setProperty("--app-font-sans", font.css);

  // Only touch font size when it differs from default — avoids stale large values
  if (prefs.fontSize !== 100) {
    root.style.fontSize = `${prefs.fontSize}%`;
  } else {
    root.style.removeProperty("font-size");
  }
}

export function savePreferences(prefs: Preferences) {
  localStorage.setItem("4trio-prefs", JSON.stringify({ ...prefs, version: PREFS_VERSION }));
  applyPreferences(prefs);
}
