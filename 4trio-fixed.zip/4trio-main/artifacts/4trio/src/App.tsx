import { Component, lazy, Suspense, useEffect, type ErrorInfo, type ReactNode } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { hasCompletedOnboarding } from "@/lib/onboarding";

const Landing  = lazy(() => import("@/pages/landing"));
const Chat     = lazy(() => import("@/pages/chat"));
const Settings = lazy(() => import("@/pages/settings"));
const NotFound = lazy(() => import("@/pages/not-found"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});


class ChatErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: unknown, info: ErrorInfo) {
    console.error("Chat page crashed", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
          <div className="max-w-sm rounded-2xl border border-border bg-card p-5 text-center shadow-lg">
            <h1 className="text-base font-semibold mb-2">Chat had a problem</h1>
            <p className="text-sm text-muted-foreground mb-4">
              The page stayed open, but one chat view failed to render. Refresh and try a smaller JPG or PNG image.
            </p>
            <button
              type="button"
              className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
              onClick={() => window.location.reload()}
            >
              Reload chat
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function PageLoader() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <span className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );
}

function RedirectTo({ path }: { path: string }) {
  const [, setLocation] = useLocation();

  useEffect(() => {
    setLocation(path, { replace: true });
  }, [path, setLocation]);

  return <PageLoader />;
}

function HomeRedirect() {
  return <RedirectTo path={hasCompletedOnboarding() ? "/chat" : "/intro"} />;
}

function RequireOnboarding({ children }: { children: ReactNode }) {
  if (!hasCompletedOnboarding()) {
    return <RedirectTo path="/intro" />;
  }

  return <>{children}</>;
}

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/intro" component={Landing} />
        <Route path="/chat">
          <RequireOnboarding>
            <ChatErrorBoundary>
              <Chat />
            </ChatErrorBoundary>
          </RequireOnboarding>
        </Route>
        <Route path="/settings">
          <RequireOnboarding>
            <Settings />
          </RequireOnboarding>
        </Route>
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
