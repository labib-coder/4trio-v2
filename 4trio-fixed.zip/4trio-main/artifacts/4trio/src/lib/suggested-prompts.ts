export const SUGGESTED_PROMPT_COUNT = 6;

export const SUGGESTED_PROMPT_BANK = [
  "🎭 Roast my Instagram bio brutally",
  "🧠 Guess my personality from 5 questions",
  "💰 Give me a business idea I can start this weekend",
  "🤯 Tell me a true fact that sounds fake",
  "⚖️ Debate me like a lawyer",
  "🚩 Analyze my red flags",
  "📚 Make me a study plan for tonight",
  "💪 Build me a workout plan with no equipment",
  "🎬 Give me a viral YouTube video idea",
  "🕵️ Ask me questions and guess my future career",
  "🧩 Give me the hardest riddle you know",
  "🔥 Turn my boring idea into something viral",
  "💸 How can a teenager make money legally?",
  "🧠 Test my IQ with 5 tricky questions",
  "🎮 Create a game idea better than Roblox",
  "📱 Rate my phone setup like a tech reviewer",
  "👀 Tell me what my texting style says about me",
  "📝 Rewrite this to sound smarter",
  "😂 Make a joke only smart people get",
  "🌍 Explain a conspiracy theory logically",
  "🚀 Turn my hobby into a startup",
  "🎤 Write me a rap verse about my life",
  "📸 Tell me how to make my profile look cooler",
  "🧪 Explain something science-y in a fun way",
  "🏆 Make me a 30-day self-improvement challenge",
  "👑 Give me villain-level confidence advice",
  "🧊 Give me the coldest comeback possible",
  "🧠 Teach me something useful in 60 seconds",
  "🕹️ Create a character based on my personality",
  "💬 Give me a deep question to ask my friends",
  "🎯 Design my perfect morning routine",
  "🧨 Make my idea sound like a movie trailer",
  "🗣️ Give me a comeback that sounds calm but savage",
  "🧭 Ask me 7 questions and recommend a life path",
  "🎨 Turn my room into a vibe with cheap upgrades",
  "🔮 Predict my next obsession from my answers",
  "📈 Give me a 7-day plan to level up fast",
  "🧠 Explain a hard topic using memes",
  "🎲 Invent a chaotic party game for my friends",
  "🛠️ Turn a random skill into a side hustle",
] as const;

export function getRandomSuggestedPrompts(count = SUGGESTED_PROMPT_COUNT): string[] {
  const copy = [...SUGGESTED_PROMPT_BANK];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, Math.min(count, copy.length));
}
