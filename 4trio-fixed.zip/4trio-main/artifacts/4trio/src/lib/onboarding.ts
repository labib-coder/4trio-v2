export const ONBOARDING_STORAGE_KEY = "hasCompletedOnboarding";
export const ONBOARDING_COMPLETE_VALUE = "true";

function getBrowserStorage(): Storage | null {
  if (typeof window === "undefined") return null;
  return window.localStorage;
}

export function hasCompletedOnboarding() {
  return (
    getBrowserStorage()?.getItem(ONBOARDING_STORAGE_KEY) ===
    ONBOARDING_COMPLETE_VALUE
  );
}

export function completeOnboarding() {
  getBrowserStorage()?.setItem(
    ONBOARDING_STORAGE_KEY,
    ONBOARDING_COMPLETE_VALUE,
  );
}

export function resetOnboarding() {
  getBrowserStorage()?.removeItem(ONBOARDING_STORAGE_KEY);
}
