export type ProviderId = "auto" | "groq" | "gemini" | "cerebras" | "openrouter" | "uncensored";

export interface ProviderCapabilities {
  text: boolean;
  vision: boolean;
  imageGeneration: boolean;
  voiceReadAloud: boolean;
  maxImages: number;
  maxTokens: number;
  contextWindow: number;
}

export interface ProviderModelInfo {
  id: string;
  label: string;
  tags?: string[];
  capabilities: ProviderCapabilities;
}

export interface ProviderInfo {
  label: string;
  badge: string | null;
  desc: string;
  capabilities: ProviderCapabilities;
  defaultModel?: string;
  models?: ProviderModelInfo[];
}

export const DEFAULT_CAPABILITIES: ProviderCapabilities = {
  text: true,
  vision: false,
  imageGeneration: false,
  voiceReadAloud: true,
  maxImages: 0,
  maxTokens: 2000,
  contextWindow: 32768,
};

const GROQ_CAPABILITIES: ProviderCapabilities = { text: true, vision: true, imageGeneration: false, voiceReadAloud: true, maxImages: 5, maxTokens: 2500, contextWindow: 131072 };
const GEMINI_CAPABILITIES: ProviderCapabilities = { text: true, vision: true, imageGeneration: true, voiceReadAloud: true, maxImages: 16, maxTokens: 8192, contextWindow: 1048576 };
const CEREBRAS_CAPABILITIES: ProviderCapabilities = { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 4000, contextWindow: 131072 };
const OPENROUTER_CAPABILITIES: ProviderCapabilities = { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 4000, contextWindow: 131072 };
const UNCENSORED_CAPABILITIES: ProviderCapabilities = { text: true, vision: false, imageGeneration: false, voiceReadAloud: true, maxImages: 0, maxTokens: 512, contextWindow: 8192 };

export const PROVIDER_INFO: Record<ProviderId, ProviderInfo> = {
  auto:        { label: "Auto",            badge: "smart",       desc: "Picks the best configured provider for each message.", capabilities: { text: true, vision: true, imageGeneration: true, voiceReadAloud: true, maxImages: 16, maxTokens: 8192, contextWindow: 1048576 } },
  groq:        { label: "Groq",            badge: "fast",        desc: "Fast text chat with vision support on compatible models.", capabilities: GROQ_CAPABILITIES, defaultModel: "openai/gpt-oss-20b", models: [
    { id: "openai/gpt-oss-20b", label: "GPT OSS 20B", tags: ["text", "fast"], capabilities: GROQ_CAPABILITIES },
    { id: "openai/gpt-oss-120b", label: "GPT OSS 120B", tags: ["code", "reasoning"], capabilities: { ...GROQ_CAPABILITIES, vision: false, maxImages: 0 } },
    { id: "meta-llama/llama-4-scout-17b-16e-instruct", label: "Llama 4 Scout", tags: ["vision"], capabilities: GROQ_CAPABILITIES },
  ] },
  gemini:      { label: "Gemini",          badge: null,          desc: "Strong multimodal model for image understanding and long context.", capabilities: GEMINI_CAPABILITIES, defaultModel: "gemini-2.0-flash", models: [
    { id: "gemini-2.0-flash", label: "Gemini Flash", tags: ["text", "vision", "image", "long-context"], capabilities: GEMINI_CAPABILITIES },
  ] },
  cerebras:    { label: "Cerebras",        badge: null,          desc: "Best for coding, math, and detailed technical responses.", capabilities: CEREBRAS_CAPABILITIES, defaultModel: "gpt-oss-120b", models: [
    { id: "gpt-oss-120b", label: "Cerebras GPT OSS 120B", tags: ["text", "code"], capabilities: CEREBRAS_CAPABILITIES },
  ] },
  openrouter:  { label: "OpenRouter",      badge: null,          desc: "Universal model router for compatible text models.", capabilities: OPENROUTER_CAPABILITIES, defaultModel: "openai/gpt-oss-120b:free", models: [
    { id: "openai/gpt-oss-120b:free", label: "OpenRouter Free", tags: ["text"], capabilities: OPENROUTER_CAPABILITIES },
  ] },
  uncensored:  { label: "Free Thinking",   badge: "unrestricted", desc: "Unrestricted Featherless.ai chat. Use it at your own discretion and be vigilant. Requests use an encrypted connection to the provider.", capabilities: UNCENSORED_CAPABILITIES, defaultModel: "failspy/Meta-Llama-3-8B-Instruct-abliterated-v3", models: [
    { id: "failspy/Meta-Llama-3-8B-Instruct-abliterated-v3", label: "Free Thinking", tags: ["text", "unrestricted"], capabilities: UNCENSORED_CAPABILITIES },
  ] },
};

export type ProviderStatusEntry = {
  configured: boolean;
  label: string;
  defaultModel: string;
  capabilities: ProviderCapabilities;
  badge?: string | null;
  desc?: string;
  healthy?: boolean;
  available?: boolean;
  latencyMs?: number | null;
  checkedAt?: string | number | null;
  models?: Array<string | ProviderModelInfo>;
};

export type ProviderStatusMap = Partial<Record<Exclude<ProviderId, "auto">, ProviderStatusEntry>>;

export const VALID_PROVIDERS: ProviderId[] = ["auto", "groq", "gemini", "cerebras", "openrouter", "uncensored"];
export const PROVIDER_ORDER: ProviderId[] = ["auto", "groq", "uncensored", "gemini", "cerebras", "openrouter"];
export const PROVIDER_STORAGE_KEY = "4trio-provider";
export const MODEL_STORAGE_KEY    = "4trio-model";
export const DEFAULT_PROVIDER: ProviderId = "auto";

export function getActiveProvider(): ProviderId {
  const v = localStorage.getItem(PROVIDER_STORAGE_KEY) as ProviderId | null;
  return v && VALID_PROVIDERS.includes(v) ? v : DEFAULT_PROVIDER;
}

function modelId(model: ProviderModelInfo | string): string {
  return typeof model === "string" ? model : model.id;
}

export function getActiveModel(id: ProviderId = getActiveProvider(), status?: ProviderStatusMap | null): string | undefined {
  if (id === "auto") return undefined;
  const stored = localStorage.getItem(MODEL_STORAGE_KEY) ?? "";
  const statusModels = status?.[id]?.models ?? [];
  const staticModels = PROVIDER_INFO[id]?.models ?? [];
  const knownModels = [...statusModels.map(modelId), ...staticModels.map((m) => m.id)];
  if (stored && (knownModels.length === 0 || knownModels.includes(stored))) return stored;
  return status?.[id]?.defaultModel ?? PROVIDER_INFO[id]?.defaultModel ?? staticModels[0]?.id;
}

export function getProviderCapabilities(id: ProviderId, status?: ProviderStatusMap | null): ProviderCapabilities {
  if (id !== "auto" && status?.[id]?.capabilities) return status[id]!.capabilities;
  return PROVIDER_INFO[id]?.capabilities ?? DEFAULT_CAPABILITIES;
}

export function getActiveProviderInfo() {
  return PROVIDER_INFO[getActiveProvider()];
}


export function getProviderInfo(id: ProviderId, status?: ProviderStatusMap | null): ProviderInfo {
  const fallback = PROVIDER_INFO[id] ?? PROVIDER_INFO.auto;
  if (id === "auto") return fallback;
  const entry = status?.[id];
  if (!entry) return fallback;
  return {
    label: entry.label ?? fallback.label,
    badge: entry.badge ?? fallback.badge,
    desc: entry.desc ?? fallback.desc,
    capabilities: entry.capabilities ?? fallback.capabilities,
    defaultModel: entry.defaultModel ?? fallback.defaultModel,
    models: fallback.models,
  };
}

export type ModelHealthReport = Partial<ProviderStatusEntry> & {
  status?: "online" | "offline" | "degraded" | "unknown" | "ok" | "ratelimit" | "pending" | "fail" | "skipped";
  message?: string | null;
  lastChecked?: string | number | null;
};

export function getModelHealthBadge(
  report?: ModelHealthReport | Record<string, Record<string, ModelHealthReport>> | null,
  provider?: Exclude<ProviderId, "auto">,
  model?: string,
): { label: string; tone: "success" | "warning" | "danger" | "neutral"; className: string; color: string } | null {
  const entry = provider && model
    ? (report as Record<string, Record<string, ModelHealthReport>> | null | undefined)?.[provider]?.[model]
    : report as ModelHealthReport | null | undefined;
  if (provider && model && !entry) return null;
  const healthy = entry?.healthy ?? entry?.available;
  if (healthy === true || entry?.status === "online" || entry?.status === "ok" || entry?.status === "ratelimit") {
    return { label: entry?.status === "ratelimit" ? "Rate limited" : "Online", tone: "success", className: "text-emerald-500", color: "text-emerald-500" };
  }
  if (entry?.status === "degraded" || entry?.status === "pending" || entry?.status === "unknown") {
    return { label: entry.status === "pending" ? "Checking" : "Unknown", tone: "warning", className: "text-amber-500", color: "text-amber-500" };
  }
  if (healthy === false || entry?.status === "offline" || entry?.status === "fail") {
    return { label: "Offline", tone: "danger", className: "text-destructive", color: "text-destructive" };
  }
  return { label: "Unknown", tone: "neutral", className: "text-muted-foreground", color: "text-muted-foreground" };
}
