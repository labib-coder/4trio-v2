import { memo, useState, useCallback, type ReactNode } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeHighlight from "rehype-highlight";
import rehypeKatex from "rehype-katex";
import rehypeRaw from "rehype-raw";
import "highlight.js/styles/github-dark.css";
import "katex/dist/katex.min.css";

type NodeChildren = { children?: ReactNode };
type CodeProps = NodeChildren & { className?: string };
type LinkProps = NodeChildren & { href?: string };

function CodeBlock({ children }: NodeChildren) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    const text = extractText(children);
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [children]);

  return (
    <div className="relative my-3 rounded-xl border border-white/8 group/code" style={{ background: "#0d1117" }}>
      <button
        onClick={handleCopy}
        className="absolute top-2 right-2 px-2 py-1 rounded-md text-[11px] font-medium text-white/50 hover:text-white/90 hover:bg-white/10 transition-colors opacity-0 group-hover/code:opacity-100 focus:opacity-100"
        title="Copy code"
      >
        {copied ? "Copied!" : "Copy"}
      </button>
      <div className="overflow-x-auto">
        <pre className="p-0 m-0 text-xs leading-relaxed" style={{ background: "transparent" }}>{children}</pre>
      </div>
    </div>
  );
}

function extractText(node: ReactNode): string {
  if (typeof node === "string") return node;
  if (typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(extractText).join("");
  if (node && typeof node === "object" && "props" in (node as object)) {
    return extractText((node as { props: { children?: ReactNode } }).props.children);
  }
  return "";
}

const MARKDOWN_COMPONENTS = {
  p:          ({ children }: NodeChildren) => <p className="chat-md-paragraph break-words">{children}</p>,
  strong:     ({ children }: NodeChildren) => <strong className="font-semibold">{children}</strong>,
  em:         ({ children }: NodeChildren) => <em className="italic">{children}</em>,
  h1:         ({ children }: NodeChildren) => <h1 className="text-base font-bold mt-4 mb-2 first:mt-0 break-words">{children}</h1>,
  h2:         ({ children }: NodeChildren) => <h2 className="text-sm font-bold mt-4 mb-1.5 first:mt-0 break-words">{children}</h2>,
  h3:         ({ children }: NodeChildren) => <h3 className="text-sm font-semibold mt-3 mb-1 first:mt-0 break-words">{children}</h3>,
  ul:         ({ children }: NodeChildren) => <ul className="list-disc list-outside ml-4 mb-2 space-y-1">{children}</ul>,
  ol:         ({ children }: NodeChildren) => <ol className="list-decimal list-outside ml-4 mb-2 space-y-1">{children}</ol>,
  li:         ({ children }: NodeChildren) => <li className="chat-md-list-item leading-relaxed break-words">{children}</li>,
  pre:        ({ children }: NodeChildren) => <CodeBlock>{children}</CodeBlock>,
  code:       ({ children, className }: CodeProps) => {
    const isBlock = Boolean(className);
    return isBlock ? (
      <code className={`${className ?? ""} block p-4 font-mono text-xs whitespace-pre`}>{children}</code>
    ) : (
      <code className="bg-black/25 rounded px-1.5 py-0.5 text-xs font-mono text-foreground/90 break-all">{children}</code>
    );
  },
  hr:         () => <hr className="border-border/50 my-4" />,
  blockquote: ({ children }: NodeChildren) => (
    <blockquote className="border-l-2 border-primary/40 pl-3 my-2 text-foreground/70 italic">{children}</blockquote>
  ),
  a:          ({ href, children }: LinkProps) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline underline-offset-2 hover:opacity-80 break-all">{children}</a>
  ),
  table:      ({ children }: NodeChildren) => (
    <div className="overflow-x-auto my-3 rounded-xl border border-border">
      <table className="min-w-full border-collapse text-sm">{children}</table>
    </div>
  ),
  thead:      ({ children }: NodeChildren) => <thead className="bg-muted/40">{children}</thead>,
  tbody:      ({ children }: NodeChildren) => <tbody className="divide-y divide-border/50">{children}</tbody>,
  tr:         ({ children }: NodeChildren) => <tr className="divide-x divide-border/50">{children}</tr>,
  th:         ({ children }: NodeChildren) => <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap">{children}</th>,
  td:         ({ children }: NodeChildren) => <td className="px-3 py-2 text-sm break-words max-w-[200px]">{children}</td>,
};

const REMARK_PLUGINS = [remarkGfm, remarkMath];
const REHYPE_PLUGINS = [rehypeKatex, rehypeRaw, rehypeHighlight];

function unwrapTextOnlyMath(content: string): string {
  const trimmed = content.trim();
  const wrapped =
    trimmed.match(/^\\\[([\s\S]*)\\\]$/) ??
    trimmed.match(/^\$\$([\s\S]*)\$\$$/) ??
    trimmed.match(/^\\\(([\s\S]*)\\\)$/) ??
    trimmed.match(/^\$([^$\n]+)\$$/);

  if (!wrapped) return content;

  const inner = wrapped[1].trim();
  const textCommand = inner.match(/^\\(?:text|textrm|mathrm|mbox)\{([\s\S]*)\}$/);
  const candidate = (textCommand?.[1] ?? inner)
    .replace(/\\([{}$%&#_])/g, "$1")
    .replace(/\\ /g, " ")
    .trim();

  const containsMathSyntax = /(?:\\(?![ {}$%&#_])|[=^_+*/<>]|\d)/.test(candidate);
  return candidate && !containsMathSyntax ? candidate : content;
}

function preprocessMath(content: string): string {
  return unwrapTextOnlyMath(content)
    .replace(/\\\[([\s\S]*?)\\\]/g, (_, inner: string) => `$$$$${inner}$$$$`)
    .replace(/\\\(([\s\S]*?)\\\)/g, (_, inner: string) => `$${inner}$`);
}

const ChatMarkdown = memo(function ChatMarkdown({ content }: { content: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={REMARK_PLUGINS}
      rehypePlugins={REHYPE_PLUGINS}
      components={MARKDOWN_COMPONENTS}
    >
      {preprocessMath(content)}
    </ReactMarkdown>
  );
});

export default ChatMarkdown;
