import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { applyPreferences, loadPreferences } from "./hooks/use-preferences";

// Apply dark class and saved preferences before first paint
document.documentElement.classList.add("dark");
applyPreferences(loadPreferences());

createRoot(document.getElementById("root")!).render(<App />);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
