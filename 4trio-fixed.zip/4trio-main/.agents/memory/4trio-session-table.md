---
name: 4trio auth session table
description: connect-pg-simple session table must be created manually; createTableIfMissing is unreliable.
---

The `user_sessions` table for `connect-pg-simple` must be created manually via SQL before the first server start. The `createTableIfMissing: true` option did not fire automatically in this environment.

**Why:** Unknown — possibly a timing issue during startup or a bug in the version used.

**How to apply:** Any time the DB is reset or migrated to a new host, run this SQL before starting the server:

```sql
CREATE TABLE IF NOT EXISTS "user_sessions" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL,
  CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("sid") NOT DEFERRABLE INITIALLY IMMEDIATE
);
CREATE INDEX IF NOT EXISTS "IDX_user_sessions_expire" ON "user_sessions" ("expire");
```

Also: `zod/v4` subpath imports in api-server routes cause esbuild bundle failures. Use `import { z } from "zod"` (main entry) in any file directly in artifacts/api-server/src/. The zod package must be added as an explicit dependency to api-server.
