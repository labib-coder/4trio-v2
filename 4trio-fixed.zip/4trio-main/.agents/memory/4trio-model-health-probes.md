---
name: 4trio model health probes
description: Probe system design, classification rules, and routing behavior for model-health.ts
---

## Rule: 401/403 from probes = "unknown", not "fail"

Raw `fetch`-based probes return 401 for Groq/Cerebras/Gemini/Uncensored even when the SDK-based chat routes work fine. This is because:
- The SDK (e.g. `groq-sdk`) may set additional headers or handle auth differently from raw fetch.
- 401 from a probe does not mean the model is broken for end users.

**How to apply:** Only classify `404` and `400` responses as `"fail"` (model doesn't exist / invalid ID). Classify `401`/`403` as `"unknown"`. The `isModelHealthy()` function treats `"unknown"` and `"pending"` as healthy so routing is not disrupted.

## Rule: Gemini probe must use GET /models/{id}, not generateContent

POST to `generateContent` with a raw fetch returns 401 for Gemini even with a valid API key. The zero-cost metadata endpoint works correctly:
```
GET https://generativelanguage.googleapis.com/v1beta/models/{modelId}?key={apiKey}
```
This validates both key validity and model existence without a generation call.

## Status semantics (model-health.ts)

| Status      | Meaning                                | Routing behavior  |
|-------------|----------------------------------------|-------------------|
| `pending`   | Probe hasn't run yet                   | Treated as healthy |
| `ok`        | 200 response                           | Healthy            |
| `ratelimit` | 429 — works, rate-limited              | Healthy            |
| `unknown`   | 401/403 — probe auth differs from SDK  | Treated as healthy |
| `fail`      | 404/400 — model doesn't exist          | Skipped in routing |
| `skipped`   | Provider key not configured            | Skipped            |

## OpenRouter dead models (verified June 2026)

These three OpenRouter free-tier models return 404 and are correctly flagged as `"fail"`:
- `google/gemma-3-27b-it:free`
- `deepseek/deepseek-r1-0528:free`
- `mistralai/mistral-7b-instruct:free`

OpenRouter models confirmed working: `openai/gpt-oss-120b:free`, `meta-llama/llama-3.3-70b-instruct:free`.
