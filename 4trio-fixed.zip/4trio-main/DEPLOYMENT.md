# Deployment Guide

4trio runs as a standard Node.js application and deploys to any host that supports Node 20+.

## Required environment variables

| Variable | Required | Description |
|---|---|---|
| `PORT` | No | Server port (default `3000`) |
| `NODE_ENV` | Yes (prod) | Set to `production` |
| `DATABASE_URL` | No | Postgres connection string |
| `SESSION_SECRET` | Recommended | Strong random string for sessions |
| `OWNER_CODE` | No | Shared secret typed into chat to verify yourself as the owner. Leave unset to disable owner verification. Never reuse a code that was ever committed to git. |
| `GROQ_API_KEY` | No* | Enables Groq chat, Groq vision models, transcription, and optional server-side natural voice |
| `GEMINI_API_KEY` | No* | Enables Gemini text and vision/image input |
| `GEMINI_CHAT_MODEL` | No | Override the Gemini model (default `gemini-2.0-flash`; use this only if your API key supports another Gemini model) |
| `GEMINI_MAX_OUTPUT_TOKENS` | No | Cap Gemini output tokens; `gemini-2.0-flash` supports up to `8192`, but lower values usually respond faster |
| `CEREBRAS_API_KEY` | No | Coding + math |
| `OPENROUTER_API_KEY` | No | Universal fallback |
| `FEATHERLESS_API_KEY` | No* | Enables Free Thinking via Featherless.ai. Keep this server-side only. |
| `FEATHERLESS_BASE_URL` | No | Override Featherless.ai OpenAI-compatible API base URL (default `https://api.featherless.ai/v1`) |
| `FEATHERLESS_CHAT_MODEL` | No | Pin a specific Featherless.ai model instead of auto-selecting and probing an available chat model |
| `FEATHERLESS_MODEL_CANDIDATES` | No | Comma-separated preferred Featherless.ai model IDs to try before auto-selected catalogue results |
| `FEATHERLESS_PROBE_MODELS` | No | Model probes are enabled by default so unavailable models are skipped; set to `false` to skip probes |
| `FEATHERLESS_STREAMING` | No | Streaming is enabled by default for faster first tokens; set to `false` only if your model/plan requires non-streaming responses |
| `ALLOWED_ORIGINS` | No | Comma-separated CORS origins for prod |

*Configure at least one text provider key (`GROQ_API_KEY`, `GEMINI_API_KEY`, `CEREBRAS_API_KEY`, `OPENROUTER_API_KEY`, or `FEATHERLESS_API_KEY`). The app is provider-agnostic and will route/fallback based on configured provider capabilities.

Generate a session secret: `openssl rand -hex 32`

## Build & start

```bash
npm install        # or: pnpm install
npm run build      # typecheck + build frontend + backend
npm start          # starts the API server (serves frontend in production)
```

The server listens on `process.env.PORT` (default `3000`). In production, the API server also serves the compiled React frontend from `artifacts/4trio/dist`.

## Health check

```
GET /api/health
```

Returns:
```json
{
  "ok": true,
  "environment": "production",
  "providersConfigured": {
    "groq": true,
    "gemini": false,
    "cerebras": true,
    "openrouter": true,
    "uncensored": false
  }
}
```

---

## Railway

1. Connect your GitHub repo in Railway.
2. Set environment variables in the **Variables** tab (see table above).
3. Railway auto-detects the build command. Override if needed:
   - **Build command:** `pnpm install && pnpm run build`
   - **Start command:** `pnpm --filter @workspace/api-server start`
4. Railway injects `PORT` automatically — no change needed.

---

## Render

1. Create a **Web Service** from your repo.
2. Set:
   - **Build command:** `pnpm install && pnpm run build`
   - **Start command:** `pnpm --filter @workspace/api-server start`
3. Add environment variables in the **Environment** panel.
4. Render injects `PORT` — no change needed.

---

## Fly.io

`fly.toml` is included in the repo. Deploy with:

```bash
fly launch          # first time
fly deploy          # subsequent deploys
fly secrets set GROQ_API_KEY=... GEMINI_API_KEY=... # etc.
```

The internal port is `8080` as configured in `fly.toml`.

---

## Docker / VPS

```bash
docker build -t 4trio .
docker run -p 3000:3000 \
  -e NODE_ENV=production \
  -e GEMINI_API_KEY=your_key \
  -e PORT=3000 \
  4trio
```

Or use `docker compose` with a `.env` file (copy `.env.example` → `.env`).

---

## Common errors

| Error | Fix |
|---|---|
| `No AI provider is configured` | Add at least one supported provider key (`GROQ_API_KEY`, `GEMINI_API_KEY`, `CEREBRAS_API_KEY`, `OPENROUTER_API_KEY`, or `FEATHERLESS_API_KEY`) |
| `Cannot find module '...'` | Run `pnpm install` before `pnpm run build` |
| `Port already in use` | Set a different `PORT` env var |
| `CORS error in browser` | Set `ALLOWED_ORIGINS` to your frontend domain |
| `Database connection failed` | Check `DATABASE_URL` format and network access |
| Provider returns 429 | Rate limit hit — wait briefly and try again |
| `Gemini model ... is not available for this API key` | Keep the default `gemini-2.0-flash`, or set `GEMINI_CHAT_MODEL` to a model listed for the same Gemini API key/project |
